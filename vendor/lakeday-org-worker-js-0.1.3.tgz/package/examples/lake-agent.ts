import { defineAgent } from "@lakeday-org/worker-js/agent";

export default defineAgent({
	instructions:
		"Answer using the actual lake catalog. Cite the table names returned by your tool.",
	model: "gpt-5.6-sol",
	maxSteps: 8,
	tools: [
		{
			name: "describe_lake",
			description: "Inspect tables in the granted data lake.",
			parameters: {
				type: "object",
				properties: {},
				additionalProperties: false,
			},
			replay: "read",
			async execute(_arguments, { env }) {
				if (!env.QUERY) throw new Error("Grant query when creating this agent");
				const response = await env.QUERY.fetch("https://query/describe");
				if (!response.ok)
					throw new Error(`Catalog returned HTTP ${response.status}`);
				return response.json();
			},
		},
	],
});
