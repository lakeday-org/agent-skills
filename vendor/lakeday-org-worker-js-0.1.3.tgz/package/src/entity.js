/**
 * One event-sourced object.
 *
 * Everything is an entity carrying a `kind` tag: user, repo, worker, table,
 * dashboard, session, stream. A session is an entity tagged `session`; it is
 * not special. Any entity can carry facts, links, decisions and logs.
 *
 * The object's own property graph is the only copy of its history. Each event
 * is one graph node with real fields, anchored to the object by one edge whose
 * kind is the event's class, so the object's history is directly queryable
 * where it lives. Nothing is published, mirrored, or indexed anywhere else:
 * an edge between two objects is a reference, and the reference names the
 * other object's id rather than copying its rows.
 */

const ID = /^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/;
/** One event is one graph node; node properties hold at most 64 KiB. */
const MAX_BYTES = 32 * 1024;
/** Bounded scan window for one page of the whole log. */
const SCAN = 100;
/**
 * Anchor edge IDs sort newest first.
 *
 * A traversal yields edges in ID order and truncates at the caller's limit, so
 * a descending key is what makes a bounded class read return the recent tail
 * rather than an arbitrary window of the oldest events.
 */
function anchor(sequence) {
	return `s${(Number.MAX_SAFE_INTEGER - sequence).toString().padStart(16, "0")}`;
}
/** Event class -> anchor edge kind. Reads select a class without a scan. */
const CLASS = {
	"object.created": "created",
	"object.updated": "updated",
	"object.context": "context",
	"fact.asserted": "fact",
	"fact.retracted": "fact",
	"link.asserted": "link",
	"link.retracted": "link",
	"decision.recorded": "decision",
	"decision.outcome": "outcome",
	"log.appended": "log",
};
/** Read paths that select one event class rather than the whole history. */
const SELECT = {
	"/facts": "fact",
	"/links": "link",
	"/decisions": "decision",
	"/outcomes": "outcome",
	"/log": "log",
};

/** A contract error that can be safely returned to an API caller. */
class ContractError extends Error {
	constructor(status, message) {
		super(message);
		this.status = status;
	}
}
/** Requires an explicit, portable resource or record identity. */
function identifier(value, label) {
	if (typeof value !== "string" || !ID.test(value))
		throw new ContractError(400, `${label} must match ${ID}`);
	return value;
}
/** Requires a bounded nonempty string. */
function text(value, label) {
	if (typeof value !== "string" || !value.trim() || value.length > 8192)
		throw new ContractError(
			400,
			`${label} must be a nonempty string of at most 8192 characters`
		);
	return value;
}
/** Requires a JSON object rather than an array or scalar. */
function record(value) {
	if (!value || typeof value !== "object" || Array.isArray(value))
		throw new ContractError(400, "body must be a JSON object");
	return value;
}
/**
 * One reference shape: an object, optionally at a point in its history.
 *
 * That covers pointing at a decision, a table version, or another object, so
 * there are no reference kinds to keep in step with anything.
 */
function point(value, label) {
	if (value === undefined) return undefined;
	if (typeof value === "number") {
		if (!Number.isSafeInteger(value) || value < 1)
			throw new ContractError(400, `${label} must be a positive sequence`);
		return value;
	}
	return identifier(value, label);
}
/** Validates a reference carried as an array entry rather than as two fields. */
function reference(value, label) {
	record(value);
	for (const key of Object.keys(value))
		if (!["object", "point"].includes(key))
			throw new ContractError(400, `${label} accepts only object and point`);
	identifier(value.object, `${label}.object`);
	point(value.point, `${label}.point`);
	return {
		object: value.object,
		...(value.point === undefined ? {} : { point: value.point }),
	};
}
/** Keeps equivalent JSON bodies equivalent across retries. */
function canonical(value) {
	if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
	if (value !== null && typeof value === "object")
		return `{${Object.keys(value)
			.sort()
			.map((k) => `${JSON.stringify(k)}:${canonical(value[k])}`)
			.join(",")}}`;
	return JSON.stringify(value);
}

/**
 * Stores one object's history as its own property graph.
 *
 * Durable state is exactly three things: the graph nodes that are the events,
 * one `head` watermark that is also the compare-and-swap token, and one
 * receipt per idempotency key. `head` and the receipts hold no event data, so
 * no stored value can disagree with another.
 */
export class EntityDO {
	constructor(state, env) {
		this.storage = state.storage;
		this.doId = state.id.toString();
		this.env = env;
	}
	/** Executes a narrow, authenticated storage command. */
	async command(op, args) {
		return JSON.parse(await this.storage.lance(JSON.stringify({ op, args })));
	}
	/** Reads a JSON value from this object's durable shard. */
	async read(key) {
		const value = await this.command("kv.get", { key });
		return value === null ? null : JSON.parse(value);
	}
	/** Reconstructs an event from its graph node. */
	event(node) {
		const { seq, at, type, ...data } = node.properties ?? {};
		return {
			object_id: this.id,
			object_do_id: this.doId,
			sequence: seq,
			type,
			timestamp: at,
			data,
		};
	}
	/** Reads an ordered window of this object's own events by sequence. */
	async window(from, through) {
		if (from > through) return [];
		const ids = [];
		for (let sequence = from; sequence <= through; sequence++)
			ids.push(`e${sequence}`);
		const nodes = await this.command("graph.get_nodes", { ids });
		return nodes.map((node) => this.event(node));
	}
	/** Reads one event by sequence, or null when the pointer is unset. */
	async at(sequence) {
		if (!sequence) return null;
		const [event] = await this.window(sequence, sequence);
		return event ?? null;
	}
	/** Reads the object's events of one class, newest first, bounded by limit. */
	async select(kind, limit, filter) {
		const response = await this.command("graph.neighbors", {
			id: "self",
			direction: "out",
			edgeKinds: [kind],
			depth: 1,
			limit,
			...(filter ? { nodeFilter: filter } : {}),
		});
		return (response.nodes ?? [])
			.map((node) => this.event(node))
			.filter((event) => event.sequence <= this.sequence)
			.sort((left, right) => right.sequence - left.sequence);
	}
	/**
	 * Replaces `head` under compare-and-swap, optionally alongside a receipt.
	 *
	 * `head` is one record: the watermark, two pointers into this object's own
	 * history, and any claim in flight. Keeping them in one key means a write
	 * reads one key and swaps one key. Every storage command is separately
	 * authorized by the control plane, so the command count per mutation is a
	 * cost worth minimizing.
	 */
	async swap(next, puts) {
		const serialized = JSON.stringify(next);
		const applied = await this.command("kv.batch", {
			checks: [{ key: "head", value: this.stored }],
			puts: { head: serialized, ...puts },
			deletes: [],
		});
		if (!applied)
			throw new ContractError(
				409,
				"concurrent mutation; retry with the same idempotency key"
			);
		this.stored = serialized;
		this.head = next;
		this.sequence = next.sequence;
	}
	/** Admits a claimed sequence: advances the watermark and records the receipt. */
	async publish(claim, type) {
		const { claim: pending, ...rest } = this.head;
		void pending;
		await this.swap(
			{
				...rest,
				sequence: claim.sequence,
				...(type === "object.updated" ? { identity_at: claim.sequence } : {}),
				...(type === "object.context" ? { context_at: claim.sequence } : {}),
			},
			{
				[`receipt:${claim.key}`]: JSON.stringify({
					signature: claim.signature,
					sequence: claim.sequence,
				}),
			}
		);
	}
	/**
	 * Settles a claim left behind by an interrupted append.
	 *
	 * The claimed event either reached the graph or it did not, and that is the
	 * whole question: admit it, or drop the claim so the sequence is free
	 * again. The next write resolves it, so an interrupted append never blocks
	 * the object and never needs a repair tool.
	 */
	async settle() {
		const claim = this.head.claim;
		if (!claim) return;
		const [event] = await this.window(claim.sequence, claim.sequence);
		if (event) return this.publish(claim, event.type);
		const { claim: dropped, ...rest } = this.head;
		void dropped;
		await this.swap(rest, {});
	}
	/** Finds the live event that claimed one record ID within this object. */
	async claimed(kind, id) {
		const [event] = await this.select(kind, 1000, {
			record: { $eq: id },
		});
		return event ?? null;
	}
	/** Serves the resource contract and keeps internals out of client errors. */
	async fetch(request) {
		try {
			return await this.route(request);
		} catch (error) {
			if (!(error instanceof ContractError))
				console.error(
					JSON.stringify({
						event: "entity.operation.failed",
						path: new URL(request.url).pathname,
						message: error instanceof Error ? error.message : String(error),
					})
				);
			return Response.json(
				{
					error:
						error instanceof ContractError
							? error.message
							: "Durable operation unavailable; retry with the same idempotency key",
					...(error instanceof ContractError ? {} : { retryable: true }),
				},
				{ status: error instanceof ContractError ? error.status : 503 }
			);
		}
	}
	/** Validates the shared attribution and reference fields of any mutation. */
	attribution(data, required) {
		if (required) identifier(data.actor_id, "actor_id");
		else if (data.actor_id !== undefined) identifier(data.actor_id, "actor_id");
		if (data.about !== undefined) identifier(data.about, "about");
		if (data.about_point !== undefined)
			data.about_point = point(data.about_point, "about_point");
		if (data.evidence !== undefined) {
			if (!Array.isArray(data.evidence) || data.evidence.length > 32)
				throw new ContractError(
					400,
					"evidence must be an array of at most 32 references"
				);
			data.evidence = data.evidence.map((value) =>
				reference(value, "evidence")
			);
		}
		if (data.record !== undefined)
			throw new ContractError(400, "record is derived from the operation path");
	}
	/** Validates a mutation and derives its event type and record claim. */
	async mutation(path, data, head) {
		if (path === "") {
			if (head) throw new ContractError(409, "resource already exists");
			this.attribution(data, false);
			identifier(data.kind, "kind");
			text(data.name, "name");
			return { type: "object.created" };
		}
		if (!head) throw new ContractError(404, "resource not found");
		this.attribution(data, true);
		if (path === "/identity") {
			text(data.name, "name");
			return { type: "object.updated" };
		}
		if (path === "/context") return { type: "object.context" };
		if (path === "/log") {
			text(data.label, "label");
			return { type: "log.appended" };
		}
		if (path === "/facts" || path === "/links") {
			const id = identifier(data.id, "id");
			text(data.predicate, "predicate");
			if (path === "/facts" && !Object.hasOwn(data, "value"))
				throw new ContractError(400, "fact value is required");
			if (path === "/links") identifier(data.about, "about");
			const kind = path === "/facts" ? "fact" : "link";
			if (await this.claimed(kind, id))
				throw new ContractError(409, "record ID already exists");
			delete data.id;
			return { type: `${kind}.asserted`, record: id };
		}
		if (path === "/decisions") {
			const id = identifier(data.id, "id");
			text(data.choice, "choice");
			text(data.rationale, "rationale");
			if (
				data.alternatives !== undefined &&
				(!Array.isArray(data.alternatives) ||
					data.alternatives.some((value) => typeof value !== "string"))
			)
				throw new ContractError(400, "alternatives must be strings");
			if (await this.claimed("decision", id))
				throw new ContractError(409, "record ID already exists");
			delete data.id;
			return { type: "decision.recorded", record: id };
		}
		const retract = /^\/(facts|links)\/([^/]+)\/retract$/.exec(path);
		if (retract) {
			const kind = retract[1] === "facts" ? "fact" : "link";
			const id = identifier(retract[2], "id");
			const original = await this.claimed(kind, id);
			if (!original) throw new ContractError(404, "assertion not found");
			if (original.data.actor_id !== data.actor_id)
				throw new ContractError(
					409,
					"retraction must retain the original attribution; record disagreement as a new assertion"
				);
			// A retraction points at what it retracts rather than deleting it.
			data.about = this.id;
			data.about_point = original.sequence;
			data.predicate = original.data.predicate;
			return { type: `${kind}.retracted` };
		}
		const outcome = /^\/decisions\/([^/]+)\/outcomes$/.exec(path);
		if (outcome) {
			const id = identifier(outcome[1], "decision id");
			text(data.outcome, "outcome");
			const original = await this.claimed("decision", id);
			if (!original) throw new ContractError(404, "decision not found");
			data.about = this.id;
			data.about_point = original.sequence;
			return { type: "decision.outcome" };
		}
		throw new ContractError(404, "operation not found");
	}
	/** Reads bounded pages without discarding earlier admitted history. */
	async history(url, path) {
		const after = Number(url.searchParams.get("after") ?? 0),
			limit = Number(url.searchParams.get("limit") ?? 50);
		if (
			!Number.isSafeInteger(after) ||
			after < 0 ||
			!Number.isSafeInteger(limit) ||
			limit < 1 ||
			limit > 100
		)
			throw new ContractError(
				400,
				"after must be nonnegative; limit must be 1..100"
			);
		// A class read is index-backed and newest first: it is the read that
		// replaced `ORDER BY timestamp DESC LIMIT n`, and paging a filtered
		// class from sequence zero would bury a recent record behind the log.
		const select = SELECT[path];
		if (select)
			return Response.json({
				events: await this.select(select, limit),
				next_after: null,
				sequence: this.sequence,
			});
		const through = Math.min(this.sequence, after + Math.min(limit, SCAN));
		return Response.json({
			events: await this.window(after + 1, through),
			next_after: through < this.sequence ? through : null,
			sequence: this.sequence,
		});
	}
	/** Routes one named object; the caller cannot select another through the body. */
	async route(request) {
		const url = new URL(request.url);
		let parts;
		try {
			parts = url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
		} catch {
			throw new ContractError(400, "invalid URL encoding");
		}
		if (parts.some((part) => part.includes("/")))
			throw new ContractError(400, "encoded slashes are not resource IDs");
		const id = identifier(parts.shift() ?? "", "object id");
		const path = parts.length ? `/${parts.join("/")}` : "";
		this.id = id;
		// One read of one key carries the watermark, the history pointers and
		// any claim in flight.
		this.stored = await this.command("kv.get", { key: "head" });
		const head = this.stored === null ? null : JSON.parse(this.stored);
		if (head && head.id !== id)
			throw new ContractError(409, "object identity does not match route");
		this.head = head ?? { id, sequence: 0 };
		this.sequence = this.head.sequence;
		if (request.method === "GET") {
			// A create interrupted before its event was admitted leaves a
			// watermark of zero, which is still no resource.
			if (!this.sequence) throw new ContractError(404, "resource not found");
			return this.get(url, path, parts);
		}
		if (request.method !== "POST")
			throw new ContractError(405, "use GET or POST");
		// A write settles an interrupted predecessor first, so a claim can never
		// wedge the object and no operator repair step exists.
		await this.settle();
		return this.append(request, path, this.sequence ? this.head : null);
	}
	/**
	 * Answers a read from this object's own rows.
	 *
	 * Identity and context are folded from the object's own events when asked,
	 * so no current-state record is stored that could fall behind the history
	 * it summarizes.
	 */
	async get(url, path, parts) {
		if (path === "" || path === "/context") {
			const created = await this.at(1);
			const updated = await this.at(this.head.identity_at);
			const context = await this.at(this.head.context_at);
			return Response.json({
				id: this.id,
				kind: created?.data.kind ?? null,
				sequence: this.sequence,
				object_do_id: this.doId,
				identity: { ...created?.data, ...updated?.data },
				...(context ? { context: context.data } : {}),
			});
		}
		const record = /^\/(facts|links|decisions)\/([^/]+)$/.exec(path);
		if (record) {
			const kind = { facts: "fact", links: "link", decisions: "decision" }[
				record[1]
			];
			const event = await this.claimed(
				kind,
				identifier(record[2], "record id")
			);
			if (!event) throw new ContractError(404, "record not found");
			return Response.json(event);
		}
		// A projection is a query. `refs` names one object and returns this
		// object's own events about it, assembled from this object's own rows.
		if (path === "/refs") {
			const about = identifier(url.searchParams.get("object"), "object");
			const kind = url.searchParams.get("kind") ?? "decision";
			if (!Object.values(CLASS).includes(kind))
				throw new ContractError(400, "unknown reference kind");
			const limit = Number(url.searchParams.get("limit") ?? 50);
			if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000)
				throw new ContractError(400, "limit must be 1..1000");
			return Response.json({
				events: await this.select(kind, limit, { about: { $eq: about } }),
				sequence: this.sequence,
			});
		}
		const outcomes = /^\/decisions\/([^/]+)\/outcomes$/.exec(path);
		if (outcomes) {
			const original = await this.claimed(
				"decision",
				identifier(outcomes[1], "decision id")
			);
			if (!original) throw new ContractError(404, "decision not found");
			const limit = Number(url.searchParams.get("limit") ?? 50);
			if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000)
				throw new ContractError(400, "limit must be 1..1000");
			const events = (
				await this.select("outcome", limit, {
					about_point: { $eq: original.sequence },
				})
			).filter((event) => event.data.about === this.id);
			return Response.json({ events, sequence: this.sequence });
		}
		if (["/history", "/facts", "/links", "/decisions", "/outcomes", "/log"].includes(path))
			return this.history(url, path);
		void parts;
		throw new ContractError(404, "operation not found");
	}
	/**
	 * Appends one event.
	 *
	 * The graph node and its anchor edge are written before `head` advances.
	 * Both ids are derived from the sequence, so a retry at the same sequence
	 * replaces them, and a read never sees past `head`: an interrupted append
	 * leaves nothing to repair and nothing to publish afterwards.
	 */
	async append(request, path, head) {
		const key = identifier(
			request.headers.get("idempotency-key"),
			"idempotency-key"
		);
		const bytes = new Uint8Array(await request.arrayBuffer());
		if (bytes.byteLength > MAX_BYTES)
			throw new ContractError(413, "mutation exceeds 32 KiB");
		let data;
		try {
			data = JSON.parse(new TextDecoder().decode(bytes));
		} catch {
			throw new ContractError(400, "body must be valid JSON");
		}
		record(data);
		for (const field of ["seq", "at", "type"])
			if (data[field] !== undefined)
				throw new ContractError(400, `${field} is a reserved event field`);
		const signature = canonical({ path, data });
		const receipt = await this.read(`receipt:${key}`);
		if (receipt) {
			if (receipt.signature !== signature)
				throw new ContractError(
					409,
					"idempotency key was used for a different mutation"
				);
			const [event] = await this.window(receipt.sequence, receipt.sequence);
			return Response.json(event, { status: 201 });
		}
		const { type, record: recordId } = await this.mutation(path, data, head);
		const sequence = this.sequence + 1;
		// Claim the sequence before writing anything. Nothing serializes two
		// callers of one object -- the host's event gate covers one storage
		// command, not a read-modify-write across several -- so this
		// compare-and-swap is what makes exactly one of them the writer of this
		// sequence. A loser writes nothing and is told to retry.
		const claim = { key, signature, sequence };
		await this.swap({ ...this.head, claim }, {});
		const properties = {
			...data,
			...(recordId ? { record: recordId } : {}),
			seq: sequence,
			at: new Date().toISOString(),
			type,
		};
		const nodes = [{ id: `e${sequence}`, kind: CLASS[type], properties }];
		if (!head) {
			// The anchor exists so every event has one queryable edge home.
			nodes.unshift({
				id: "self",
				kind: "object",
				properties: { id: this.id },
			});
			for (const property of ["about", "record"])
				await this.command("graph.property_index_create", {
					scope: "node",
					propertyName: property,
					indexType: "string",
				});
			await this.command("graph.property_index_create", {
				scope: "node",
				propertyName: "about_point",
				indexType: "number",
			});
		}
		await this.command("graph.upsert_nodes", { nodes });
		await this.command("graph.upsert_edges", {
			edges: [
				{
					id: anchor(sequence),
					from: "self",
					to: `e${sequence}`,
					kind: CLASS[type],
				},
			],
		});
		await this.publish(claim, type);
		return Response.json(this.event({ properties }), { status: 201 });
	}
}

/** Creates an HTTP client using either a resource endpoint or a granted binding. */
export function createEntityClient({
	endpoint,
	fetch: transport = globalThis.fetch,
	headers = {},
}) {
	const base = endpoint.replace(/\/+$/, "");
	async function call(id, path, body, key) {
		identifier(id, "object id");
		const response = await transport(
			new Request(`${base}/${encodeURIComponent(id)}${path}`, {
				method: body === undefined ? "GET" : "POST",
				headers: {
					...headers,
					"content-type": "application/json",
					...(key ? { "idempotency-key": key } : {}),
				},
				...(body === undefined ? {} : { body: JSON.stringify(body) }),
			})
		);
		const result = await response.json();
		if (!response.ok)
			throw new Error(
				`Entity HTTP ${response.status}: ${JSON.stringify(result)}`
			);
		return result;
	}
	return Object.freeze({
		create: (id, data, key) => call(id, "", data, key),
		get: (id) => call(id, ""),
		history: (id, { after = 0, limit = 50 } = {}) =>
			call(id, `/history?after=${after}&limit=${limit}`),
		refs: (id, object, { kind = "decision", limit = 50 } = {}) =>
			call(
				id,
				`/refs?object=${encodeURIComponent(object)}&kind=${kind}&limit=${limit}`
			),
		append: (id, operation, data, key) => {
			if (
				!/^\/[a-zA-Z0-9_.:%/-]+$/.test(operation) ||
				operation
					.split("/")
					.slice(1)
					.some((part) => {
						try {
							identifier(decodeURIComponent(part), "operation segment");
							return part === "." || part === "..";
						} catch {
							return true;
						}
					})
			)
				throw new TypeError("invalid operation path");
			return call(id, operation, data, key);
		},
	});
}
