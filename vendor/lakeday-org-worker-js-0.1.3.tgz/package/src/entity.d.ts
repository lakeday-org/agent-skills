/**
 * One reference shape: an object, optionally at a point in its history.
 *
 * A point is either a record ID claimed inside that object or one of its
 * event sequences, so a reference can name a decision, a table version, or
 * the object as a whole without introducing reference kinds.
 */
export interface Reference {
	object: string;
	point?: string | number;
}
export interface EntityEvent {
	object_id: string;
	object_do_id: string;
	sequence: number;
	type:
		| "object.created"
		| "object.updated"
		| "object.context"
		| "fact.asserted"
		| "fact.retracted"
		| "link.asserted"
		| "link.retracted"
		| "decision.recorded"
		| "decision.outcome"
		| "log.appended";
	timestamp: string;
	data: Record<string, unknown>;
}
export interface EntityState {
	id: string;
	kind: string | null;
	sequence: number;
	object_do_id: string;
	identity: Record<string, unknown>;
	context?: Record<string, unknown>;
}
export interface EntityPage {
	events: EntityEvent[];
	next_after: number | null;
	sequence: number;
}
export interface EntityStorage {
	lance(command: string): Promise<string>;
}
/** Every object is an entity carrying a `kind` tag; a session is not special. */
export class EntityDO {
	constructor(
		state: { id: { toString(): string }; storage: EntityStorage },
		env: unknown,
	);
	fetch(request: Request): Promise<Response>;
}
/** Explicitly granted Worker namespace. Names are stable within the deployment. */
export interface EntityNamespace {
	fetch(input: Request | string, init?: RequestInit): Promise<Response>;
	getByName(name: string): {
		id: string;
		fetch(input: Request | string, init?: RequestInit): Promise<Response>;
	};
}
export function createEntityClient(options: {
	endpoint: string;
	fetch?: (request: Request) => Promise<Response>;
	headers?: Record<string, string>;
}): {
	create(
		id: string,
		data: { kind: string; name: string } & Record<string, unknown>,
		idempotencyKey: string,
	): Promise<EntityEvent>;
	get(id: string): Promise<EntityState>;
	history(
		id: string,
		options?: { after?: number; limit?: number },
	): Promise<EntityPage>;
	refs(
		id: string,
		object: string,
		options?: { kind?: string; limit?: number },
	): Promise<{ events: EntityEvent[]; sequence: number }>;
	append(
		id: string,
		operation: string,
		data: Record<string, unknown>,
		idempotencyKey: string,
	): Promise<EntityEvent>;
};
