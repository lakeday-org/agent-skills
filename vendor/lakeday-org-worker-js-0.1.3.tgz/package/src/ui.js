/** Creates a thin JSX2UI client over HTTP or a granted Worker fetch binding. */
export function createUIClient({
	endpoint,
	fetch: transport = globalThis.fetch,
	headers = {},
}) {
	const base = endpoint.replace(/\/+$/, "");
	async function call(path, method, value, diagnostics = false) {
		const response = await transport(
			new Request(`${base}${path}`, {
				method,
				headers: { ...headers, "content-type": "application/json" },
				...(value === undefined ? {} : { body: JSON.stringify(value) }),
			})
		);
		const result = await response.json();
		if (!response.ok && !(diagnostics && response.status === 422))
			throw new Error(
				`JSX2UI HTTP ${response.status}: ${JSON.stringify(result)}`
			);
		return result;
	}
	const previewPath = (id) => `/previews/${encodeURIComponent(id)}`;
	return Object.freeze({
		catalog: () => call("/catalog", "GET"),
		validate: (document, checkQueries = false) =>
			call("/validate", "POST", { document, checkQueries }, true),
		async preview(document) {
			const result = await call("/previews", "POST", document);
			return {
				...result,
				viewer_url: `${base}${previewPath(result.id)}/`,
				evaluation_url: `${base}${previewPath(result.id)}/evaluate`,
			};
		},
		update: (id, document) => call(previewPath(id), "PATCH", document),
		evaluate: (id, state = {}) =>
			call(`${previewPath(id)}/evaluate`, "POST", { state }),
		inspect: (id, state = {}) =>
			call(`${previewPath(id)}/inspect`, "POST", { state }),
		assert: (id, assertions, state = {}) =>
			call(`${previewPath(id)}/assert`, "POST", { assertions, state }),
		browser: (id, operation, args = {}) =>
			call(
				`${previewPath(id)}/browser/${encodeURIComponent(operation)}`,
				"POST",
				args
			),
		package: (document) => call("/package", "POST", document),
		close: (id) => call(previewPath(id), "DELETE"),
	});
}
