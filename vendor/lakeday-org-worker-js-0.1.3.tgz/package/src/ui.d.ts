export interface UIDocument {
	/** Automatic viewer refresh at midnight in this IANA time zone. */
	refresh?: { timeZone: string; delayMinutes?: number };
	source: string;
	revision: number;
	queries?: Record<
		string,
		{
			sql: string;
			params?: Record<
				string,
				string | number | boolean | null | { state: string }
			>;
			limit: number;
		}
	>;
	state?: Record<
		string,
		{
			type: "string" | "number" | "boolean";
			value: string | number | boolean;
			options?: Array<string | number | boolean>;
			min?: number;
			max?: number;
		}
	>;
}
export interface UIPreview {
	id: string;
	viewer_url: string;
	evaluation_url: string;
	revision: number;
}
export interface UIClient {
	catalog(): Promise<Record<string, unknown>>;
	validate(
		document: UIDocument,
		checkQueries?: boolean
	): Promise<Record<string, unknown>>;
	preview(document: UIDocument): Promise<UIPreview>;
	update(id: string, document: UIDocument): Promise<Record<string, unknown>>;
	evaluate(
		id: string,
		state?: Record<string, unknown>
	): Promise<Record<string, unknown>>;
	inspect(
		id: string,
		state?: Record<string, unknown>
	): Promise<Record<string, unknown>>;
	assert(
		id: string,
		assertions: Array<{
			id: string;
			prop: string;
			equals?: unknown;
			length?: number;
		}>,
		state?: Record<string, unknown>
	): Promise<Record<string, unknown>>;
	browser(
		id: string,
		operation: string,
		args?: Record<string, unknown>
	): Promise<Record<string, unknown>>;
	package(
		document: UIDocument
	): Promise<{
		module: string;
		manifest: Record<string, unknown>;
		digest: string;
	}>;
	close(id: string): Promise<Record<string, unknown>>;
}
/** Uses the daemon API or the fetch method of an explicitly granted JSX2UI binding. */
export function createUIClient(options: {
	endpoint: string;
	fetch?: (request: Request) => Promise<Response>;
	headers?: Record<string, string>;
}): UIClient;
