/**
 * Learning: ALWAYS-mode knowledge capture and Tardigrade-style projection.
 *
 * One implementation serves three surfaces:
 *  - the V8 agent harness (`defineAgent({ learning: "always" })`), which folds
 *    its AG-UI run events through `learningComponents()` and asks
 *    `learningVerdict()` before finishing a run;
 *  - the MCP server (`session_project`, automatic provenance on pipeline and
 *    dashboard tools);
 *  - external coding-agent hooks (Claude Code, Codex, Cursor), which vendor
 *    this file and call the same functions.
 *
 * Everything here is pure. Nothing reads storage, performs network calls, or
 * depends on Node APIs, so it runs unchanged inside a Worker isolate.
 */

export const LEARNING_MODES = Object.freeze(["always", "agentic", "off"]);

const MAX_LINE = 240;

export function clip(text, max = MAX_LINE) {
	if (text == null) return "";
	const single = String(text).replace(/\s+/g, " ").trim();
	return single.length > max ? `${single.slice(0, max - 1)}…` : single;
}

export function sanitizeId(value, max = 100) {
	const cleaned = String(value)
		.replace(/[^a-zA-Z0-9_.:-]+/g, "-")
		.replace(/^[^a-zA-Z0-9]+/, "");
	return (cleaned || "x").slice(0, max);
}

/** Normalizes a learning option into { mode, budget, maxNudges }. */
export function normalizeLearning(value) {
	if (value === undefined || value === null || value === false)
		return { mode: "off", budget: 16000, maxNudges: 1 };
	const options =
		typeof value === "string"
			? { mode: value }
			: value === true
				? { mode: "always" }
				: value;
	if (!options || typeof options !== "object")
		throw new TypeError("learning must be a mode string or options object");
	const mode = options.mode ?? "always";
	if (!LEARNING_MODES.includes(mode))
		throw new TypeError(
			`learning mode must be one of ${LEARNING_MODES.join(", ")}`
		);
	const budget = options.budget ?? 16000;
	if (!Number.isInteger(budget) || budget < 500 || budget > 64000)
		throw new TypeError("learning budget must be 500..64000 characters");
	const maxNudges = options.maxNudges ?? 1;
	if (!Number.isInteger(maxNudges) || maxNudges < 0 || maxNudges > 3)
		throw new TypeError("learning maxNudges must be 0..3");
	return { mode, budget, maxNudges };
}

// --- tool classification --------------------------------------------------

/** Lakeday tools whose success is a consequential effect. */
export const CONSEQUENTIAL_TOOLS = new Set([
	"deploy_worker",
	"delete_worker",
	"deploy_pipeline",
	"run_pipeline",
	"stream_send",
	"stream_load",
	"transform_commit",
	"sink_commit",
	"lake_ingest",
	"create_collection",
	"collection_grant",
	"assign_data_source",
	"set_table_policy",
	"create_dashboard",
	"update_dashboard",
	"delete_dashboard",
]);

/** Tools that measure something (candidates for outcomes). */
export const MEASUREMENT_TOOLS = new Set([
	"query_sql",
	"inspect_dashboard",
	"evaluate_dashboard",
	"sink_read",
	"ui_render",
]);

/** Knowledge tools the model calls itself (the AGENTIC layer). */
export const RECORDING_OPERATIONS = new Set([
	"decide",
	"outcome",
	"fact",
	"link",
	"retract_fact",
	"retract_link",
	"log",
	"context",
]);

/**
 * The object operation a knowledge tool performs, for either namespace.
 * `entity_decide` and `session_decide` are the same operation on the same
 * class, so nothing downstream should have to know which spelling was used.
 */
export function knowledgeOperation(lakedayTool) {
	const match = /^(?:entity|session)_(.+)$/.exec(lakedayTool ?? "");
	return match && RECORDING_OPERATIONS.has(match[1]) ? match[1] : null;
}

/** Retained for callers that match on the tool name rather than the operation. */
export const RECORDING_TOOLS = new Set(
	["entity", "session"].flatMap((namespace) =>
		[...RECORDING_OPERATIONS].map((operation) => `${namespace}_${operation}`)
	)
);

const CODE_TOOLS = new Set([
	"Edit",
	"Write",
	"MultiEdit",
	"NotebookEdit",
	"apply_patch",
]);

/**
 * Normalizes a tool call from any surface into { name, lakedayTool, input, output, error }.
 * The V8 agent wraps product tools as `product_tool({ name, arguments })`.
 */
export function normalizeToolCall({ name, input, output, error, serverName }) {
	let toolName = name ?? "";
	let toolInput = input && typeof input === "object" ? input : {};
	if (toolName === "product_tool" && typeof toolInput.name === "string") {
		toolName = toolInput.name;
		toolInput =
			toolInput.arguments && typeof toolInput.arguments === "object"
				? toolInput.arguments
				: {};
	}
	const lakedayTool = lakedayToolName(toolName, serverName);
	const parsed = parseMaybeJson(output);
	return {
		name: toolName,
		lakedayTool,
		input: toolInput,
		output: parsed,
		error: error ?? toolError(parsed),
	};
}

/** Maps a harness tool name to the Lakeday tool it wraps, or null. */
export function lakedayToolName(name, serverName) {
	if (!name) return null;
	if (serverName && serverName !== "lakeday") return null;
	let candidate = name;
	const mcp = /^mcp__([^_]+(?:_[^_]+)*)__(.+)$/.exec(name);
	if (mcp) {
		if (mcp[1] !== "lakeday") return null;
		candidate = mcp[2];
	} else if (name.includes("__")) {
		const parts = name.split("__");
		if (parts[0] !== "lakeday") return null;
		candidate = parts.slice(1).join("__");
	} else if (name.startsWith("lakeday.")) {
		candidate = name.slice("lakeday.".length);
	}
	if (
		CONSEQUENTIAL_TOOLS.has(candidate) ||
		MEASUREMENT_TOOLS.has(candidate) ||
		RECORDING_TOOLS.has(candidate) ||
		/^(entity|session|query|stream|sink|transform|list|get|whoami|invoke|render|validate|package|ui|web|browser)_?[a-z_]*$/.test(
			candidate
		)
	)
		return candidate;
	return null;
}

function parseMaybeJson(value) {
	if (typeof value !== "string") return value;
	try {
		return JSON.parse(value);
	} catch {
		return value;
	}
}

/** Best-effort error detection on a tool result. */
export function toolError(output) {
	if (output == null) return null;
	if (typeof output === "string")
		return /^(error|Error:|\{"error"|HTTP [45]\d\d)/m.test(output.trim())
			? output.slice(0, 500)
			: null;
	if (typeof output === "object") {
		if (output.isError === true || output.is_error === true)
			return summarize(output);
		if (typeof output.error === "string") return output.error.slice(0, 500);
		if (typeof output.status === "number" && output.status >= 400)
			return summarize(output);
		if (
			output.structuredContent &&
			typeof output.structuredContent.error === "string"
		)
			return output.structuredContent.error.slice(0, 500);
	}
	return null;
}

function summarize(value) {
	try {
		return JSON.stringify(value).slice(0, 500);
	} catch {
		return String(value).slice(0, 500);
	}
}

export function classifyTool(tool) {
	if (!tool) return "other";
	if (tool.lakedayTool) {
		if (knowledgeOperation(tool.lakedayTool)) return "recording";
		if (CONSEQUENTIAL_TOOLS.has(tool.lakedayTool)) return "consequential";
		if (MEASUREMENT_TOOLS.has(tool.lakedayTool)) return "measurement";
		return "read";
	}
	if (CODE_TOOLS.has(tool.name)) return "code";
	if (
		tool.name === "Bash" &&
		typeof tool.input?.command === "string" &&
		/\bgit\s+(commit|push|merge|rebase|tag)\b/.test(tool.input.command)
	)
		return "consequential";
	return "other";
}

// --- evidence and events ---------------------------------------------------

/** Table names referenced in a SQL string (best-effort FROM/JOIN scan). */
export function tablesInSql(sql) {
	if (typeof sql !== "string") return [];
	const found = new Set();
	const re = /\b(?:from|join)\s+([a-zA-Z_][a-zA-Z0-9_.]*)/gi;
	let m;
	while ((m = re.exec(sql))) {
		const name = m[1].split(".").pop();
		if (!["select", "lateral", "unnest", "values"].includes(name.toLowerCase()))
			found.add(name);
	}
	return [...found].slice(0, 6);
}

function structuredOf(output) {
	if (!output || typeof output !== "object") return {};
	if (output.structuredContent && typeof output.structuredContent === "object")
		return output.structuredContent;
	return output;
}

/**
 * Evidence derived from a Lakeday call, in the one reference shape: an object,
 * optionally at a point in its history. A URL is not a reference, so a loaded
 * source is not cited here; it belongs in a fact value.
 */
export function evidenceFor(tool) {
	const t = tool.lakedayTool;
	const input = tool.input ?? {};
	const structured = structuredOf(tool.output);
	const version =
		structured.table_version ??
		structured.snapshot ??
		structured.version ??
		null;
	const refs = [];
	const cite = (id, v) =>
		refs.push({
			object: sanitizeId(id),
			...(v != null ? { point: sanitizeId(v) } : {}),
		});
	switch (t) {
		case "run_pipeline":
		case "deploy_pipeline":
			if (input.sink_table) cite(input.sink_table, version);
			else if (structured.sink_table) cite(structured.sink_table, version);
			break;
		case "sink_commit":
			if (input.batch?.table) cite(input.batch.table, version);
			break;
		case "lake_ingest":
			if (input.table) cite(input.table, version);
			break;
		case "stream_load":
			if (input.stream) cite(input.stream, version);
			break;
		case "query_sql":
			for (const table of tablesInSql(input.sql)) cite(table, version);
			break;
		case "inspect_dashboard":
		case "evaluate_dashboard":
		case "render_dashboard":
			if (input.id) cite(`dashboard:${sanitizeId(input.id)}`);
			break;
		default:
			break;
	}
	return refs.slice(0, 8);
}

/** The object a Lakeday call is about, or null when the call names none. */
export function aboutFor(tool) {
	const t = tool.lakedayTool;
	const input = tool.input ?? {};
	if ((t === "deploy_pipeline" || t === "run_pipeline") && input.name)
		return `pipeline:${sanitizeId(input.name)}`;
	if (
		(t === "deploy_worker" || t === "delete_worker" || t === "invoke_worker") &&
		input.worker
	)
		return `worker:${sanitizeId(input.worker)}`;
	if (t === "create_dashboard" && input.name)
		return `dashboard:${sanitizeId(input.name)}`;
	if ((t === "update_dashboard" || t === "delete_dashboard") && input.id)
		return `dashboard:${sanitizeId(input.id)}`;
	return null;
}

function describeLakedayCall(name, input) {
	switch (name) {
		case "query_sql":
			return `query_sql: ${input.sql ?? ""}`;
		case "deploy_pipeline":
			return `deploy_pipeline ${input.name}: ${input.source_stream} → ${input.output_stream} → ${input.sink_table}`;
		case "run_pipeline":
			return `run_pipeline ${input.name}`;
		case "stream_send":
			return `stream_send ${input.stream}: ${Array.isArray(input.events) ? input.events.length : "?"} events`;
		case "stream_load":
			return `stream_load ${input.stream} ← ${input.source ?? input.url ?? ""}`;
		case "lake_ingest":
			return `lake_ingest ${input.table}: ${Array.isArray(input.rows) ? input.rows.length : "?"} rows`;
		case "deploy_worker":
			return `deploy_worker ${input.worker}`;
		case "create_dashboard":
			return `create_dashboard ${input.name}`;
		case "update_dashboard":
			return `update_dashboard ${input.id}`;
		case "set_table_policy":
			return `set_table_policy ${input.collection}/${input.table_name} as ${input.sql_alias}`;
		case "collection_grant":
			return `collection_grant ${input.collection} ${input.role}${input.revoke ? " (revoke)" : ""} → ${input.email ?? input.membership_id ?? ""}`;
		case "assign_data_source":
			return `assign_data_source ${input.collection} ← ${input.worker}/${input.binding}/${input.source_name ?? input.object ?? ""}`;
		case "invoke_worker":
			return `invoke_worker ${input.worker} ${input.method ?? "GET"} ${input.path ?? "/"}`;
		default:
			return `${name} ${clip(JSON.stringify(stripLarge(input)), 150)}`;
	}
}

function describeGenericCall(name, input) {
	if (name === "Bash") return `Bash: ${input.command ?? ""}`;
	if (CODE_TOOLS.has(name))
		return `${name}: ${input.file_path ?? input.path ?? ""}`;
	return `${name}`;
}

function stripLarge(input) {
	const out = {};
	for (const [k, v] of Object.entries(input ?? {})) {
		if (typeof v === "string" && v.length > 120) out[k] = `${v.slice(0, 117)}…`;
		else if (Array.isArray(v)) out[k] = `[${v.length} items]`;
		else if (v && typeof v === "object") out[k] = "{…}";
		else out[k] = v;
	}
	return out;
}

/**
 * Bounded, non-secret summary of a tool call for one `/log` append. `type` is
 * a reserved event field, so the free text is `label` and the subject is the
 * flat `about` reference.
 */
export function toolEventData(tool, harness) {
	const input = tool.input ?? {};
	const label = tool.lakedayTool
		? describeLakedayCall(tool.lakedayTool, input)
		: describeGenericCall(tool.name, input);
	const data = {
		tool: tool.lakedayTool ?? tool.name,
		...(harness ? { harness } : {}),
		label: clip(label, 200),
		ok: !tool.error,
	};
	if (tool.error) data.error = clip(tool.error, 300);
	const evidence = evidenceFor(tool);
	if (evidence.length) data.evidence = evidence;
	const about = aboutFor(tool);
	if (about) data.about = about;
	return data;
}

// --- provenance ------------------------------------------------------------

export function externalDatasetId(source) {
	const s = String(source);
	try {
		const url = new URL(s);
		return `${url.protocol.replace(":", "")}-${url.host}${url.pathname}`.replace(
			/\/+$/,
			""
		);
	} catch {
		return s;
	}
}

/**
 * Automatic provenance: object and link writes implied by a successful
 * Lakeday call. Returns [{ op: "ensure-entity", id, data } | { op: "link", entity, data }].
 * IDs are logical (`pipeline:<name>`); callers map them to their namespace.
 */
export function provenancePlan(tool, { sessionId, projectEntity } = {}) {
	if (!tool?.lakedayTool || tool.error) return [];
	const input = tool.input ?? {};
	const plan = [];
	// The session that observed the call is cited like any other reference.
	const cited = sessionId
		? { evidence: [{ object: sanitizeId(sessionId) }] }
		: {};
	const ensureEntity = (id, kind, name, extra = {}) =>
		plan.push({
			op: "ensure-entity",
			id,
			data: { kind, name, ...extra, ...cited },
		});
	const link = (from, id, predicate, about, point) =>
		plan.push({
			op: "link",
			entity: from,
			data: {
				id: sanitizeId(id),
				predicate,
				about,
				...(point != null ? { about_point: sanitizeId(point) } : {}),
				...cited,
			},
		});
	switch (tool.lakedayTool) {
		case "deploy_pipeline": {
			const name = sanitizeId(input.name ?? "");
			if (!name) break;
			const pipeline = `pipeline:${name}`;
			const source = `dataset:${sanitizeId(input.source_stream ?? "")}`;
			const table = `dataset:${sanitizeId(input.sink_table ?? "")}`;
			ensureEntity(pipeline, "pipeline", input.name, {
				transform_worker: `${input.name}-transform`,
				sink_worker: `${input.name}-sink`,
				cron: input.cron ?? null,
			});
			ensureEntity(source, "dataset", input.source_stream, {
				source_kind: "stream",
			});
			ensureEntity(table, "dataset", input.sink_table, {
				source_kind: "lance_table",
			});
			link(pipeline, `reads-${name}`, "reads_from", source);
			link(pipeline, `writes-${name}`, "writes_to", table);
			link(table, `produced-by-${name}`, "produced_by", pipeline);
			if (projectEntity)
				link(projectEntity, `owns-pipeline-${name}`, "owns", pipeline);
			break;
		}
		case "run_pipeline": {
			const name = sanitizeId(input.name ?? "");
			const structured = structuredOf(tool.output);
			const table = structured.sink_table ?? input.sink_table;
			const version = structured.table_version ?? structured.snapshot ?? null;
			if (!name || !table) break;
			link(
				`pipeline:${name}`,
				`ran-${name}-${version ?? "latest"}`,
				"produced",
				`dataset:${sanitizeId(table)}`,
				version
			);
			break;
		}
		case "stream_load": {
			const stream = sanitizeId(input.stream ?? "");
			const source = input.source ?? input.url;
			if (!stream || !source) break;
			const streamEntity = `dataset:${stream}`;
			const external = `dataset:${sanitizeId(externalDatasetId(source))}`;
			ensureEntity(external, "dataset", String(source).slice(0, 200), {
				source_kind: "external",
				uri: String(source).slice(0, 500),
				format: input.format ?? null,
			});
			ensureEntity(streamEntity, "dataset", input.stream, {
				source_kind: "stream",
			});
			link(streamEntity, `loaded-from-${stream}`, "loaded_from", external);
			break;
		}
		case "create_dashboard": {
			const name = sanitizeId(input.name ?? "");
			if (!name) break;
			const dashboard = `dashboard:${name}`;
			ensureEntity(dashboard, "dashboard", input.name, {
				deployment_id: input.deployment_id ?? null,
			});
			const queries = input.document?.queries ?? {};
			for (const q of Object.values(queries))
				for (const table of tablesInSql(q?.sql))
					link(
						dashboard,
						`reads-${name}-${sanitizeId(table)}`,
						"reads_from",
						`dataset:${sanitizeId(table)}`
					);
			if (projectEntity)
				link(projectEntity, `owns-dashboard-${name}`, "owns", dashboard);
			break;
		}
		case "set_table_policy": {
			const table = sanitizeId(input.table_name ?? "");
			if (!table) break;
			ensureEntity(`dataset:${table}`, "dataset", input.table_name, {
				source_kind: "lance_table",
				collection: input.collection ?? null,
				sql_alias: input.sql_alias ?? null,
			});
			break;
		}
		default:
			break;
	}
	return plan;
}

// --- projection (Tardigrade components over one object's history) ----------

/** Renders the one reference shape: an object, optionally at a point. */
function refLabel(ref) {
	if (!ref || typeof ref !== "object" || typeof ref.object !== "string")
		return "";
	return ref.point === undefined ? ref.object : `${ref.object}@${ref.point}`;
}

/**
 * Log appends come in two flavours: hook-written rows whose `data` carries a
 * flat tool summary, and V8 harness rows whose `data.event` is an AG-UI event.
 * This yields a uniform `{ type, label, tool, error, ... }` for the reducers.
 */
function activityOf(event) {
	if (event.type !== "log.appended") return null;
	const d = event.data ?? {};
	if (d.event && typeof d.event === "object") {
		const ag = d.event;
		if (ag.type === "TOOL_CALL_START")
			return {
				type: "tool.call",
				tool: ag.toolCallName,
				label: ag.toolCallName,
			};
		if (ag.type === "TOOL_CALL_RESULT") {
			const output = parseMaybeJson(ag.content);
			const error = toolError(output);
			return {
				type: "tool.result",
				tool: ag.toolCallName ?? null,
				label: null,
				error,
				output,
			};
		}
		if (ag.type === "RUN_STARTED")
			return { type: "user.prompt", label: ag.input?.message ?? "" };
		if (ag.type === "CUSTOM" && ag.name === "lakeday.learning.required")
			return { type: "learning.nudge", label: ag.value?.reason ?? "" };
		if (ag.type === "CUSTOM" && ag.name === "lakeday.context.compacted")
			return { type: "compaction", label: "context compacted" };
		return null;
	}
	// `type` is a reserved event field, so a logged tool result is recognized
	// by the tool it names rather than by a type it is not allowed to carry.
	return { ...d, type: d.tool ? "tool.result" : "event" };
}

export const goalComponent = {
	name: "goal",
	initial: () => ({ goal: null }),
	reduce(state, event) {
		if (event.type !== "object.created") return state;
		const d = event.data ?? {};
		return { ...state, goal: d.goal ?? d.name ?? null };
	},
	view(state) {
		return state.goal ? [`Goal: ${clip(state.goal)}`] : [];
	},
};

export const contextComponent = {
	name: "context",
	initial: () => ({ latest: null, compactions: 0 }),
	reduce(state, event) {
		if (event.type !== "object.context") return state;
		const d = event.data ?? {};
		return {
			latest: d,
			compactions: state.compactions + (d.reason === "compaction" ? 1 : 0),
		};
	},
	view(state) {
		if (!state.latest) return [];
		const lines = [];
		if (state.latest.summary)
			lines.push(`Working context: ${clip(state.latest.summary, 600)}`);
		if (Array.isArray(state.latest.plan) && state.latest.plan.length)
			lines.push(
				`Plan: ${state.latest.plan.map((s) => clip(s, 80)).join(" → ")}`
			);
		if (Array.isArray(state.latest.open) && state.latest.open.length)
			lines.push(
				`Open: ${state.latest.open.map((s) => clip(s, 100)).join("; ")}`
			);
		if (Array.isArray(state.latest.evidence) && state.latest.evidence.length)
			lines.push(
				`References: ${state.latest.evidence.slice(0, 8).map(refLabel).join(", ")}`
			);
		return lines;
	},
};

/**
 * A decision is identified by the `record` it claimed on the object it was
 * recorded on. An outcome carries no decision ID: it points at the decision
 * event with `about` (the object) and `about_point` (its sequence), so the
 * join is by sequence within the history being folded.
 */
export const decisionsComponent = {
	name: "decisions",
	initial: () => ({ byRecord: new Map(), atSequence: new Map(), order: [] }),
	reduce(state, event) {
		if (event.type === "decision.recorded") {
			const d = event.data ?? {};
			const byRecord = new Map(state.byRecord);
			byRecord.set(d.record, {
				record: d.record,
				choice: d.choice,
				rationale: d.rationale,
				about: d.about ?? null,
				alternatives: d.alternatives ?? [],
				evidence: d.evidence ?? [],
				outcomes: [],
				sequence: event.sequence,
			});
			return {
				byRecord,
				atSequence: new Map(state.atSequence).set(event.sequence, d.record),
				order: [...state.order, d.record],
			};
		}
		if (event.type === "decision.outcome") {
			const d = event.data ?? {};
			const record = state.atSequence.get(d.about_point);
			const existing =
				record === undefined ? undefined : state.byRecord.get(record);
			if (!existing) return state;
			const byRecord = new Map(state.byRecord);
			byRecord.set(record, {
				...existing,
				outcomes: [
					...existing.outcomes,
					{ outcome: d.outcome, evidence: d.evidence ?? [] },
				],
			});
			return { ...state, byRecord };
		}
		return state;
	},
	view(state) {
		if (!state.order.length) return [];
		const lines = ["Decisions recorded here:"];
		for (const record of state.order.slice(-8)) {
			const d = state.byRecord.get(record);
			const status = d.outcomes.length
				? `outcome: ${clip(d.outcomes.at(-1).outcome, 120)}`
				: "outcome: not yet measured";
			lines.push(`- ${d.record}: ${clip(d.choice, 140)} (${status})`);
		}
		return lines;
	},
};

/**
 * Which other objects this history points at. There are no reference kinds
 * left to select on, so the key is the referenced object ID itself.
 */
export const referencesComponent = {
	name: "references",
	initial: () => ({ refs: new Map() }),
	reduce(state, event) {
		const d = event.data ?? {};
		const refs = new Map(state.refs);
		const add = (ref) => {
			if (!ref || typeof ref.object !== "string") return;
			refs.set(ref.object, { ...ref, sequence: event.sequence });
		};
		for (const ref of Array.isArray(d.evidence) ? d.evidence : []) add(ref);
		// A retraction or outcome points back at this same object; that is
		// bookkeeping, not a reference to somewhere else.
		if (typeof d.about === "string" && d.about !== event.object_id)
			add({
				object: d.about,
				...(d.about_point === undefined ? {} : { point: d.about_point }),
			});
		return refs.size === state.refs.size ? state : { refs };
	},
	view(state) {
		if (!state.refs.size) return [];
		const items = [...state.refs.values()].slice(-10).map(refLabel);
		return [`Objects referenced: ${items.join(", ")}`];
	},
};

export const recentComponent = {
	name: "recent",
	initial: () => ({ events: [] }),
	reduce(state, event) {
		const a = activityOf(event);
		if (!a || a.type === "tool.call") return state;
		const entry = {
			type: a.type,
			label: a.label ?? a.text ?? a.tool ?? "",
			error: a.error ?? null,
			sequence: event.sequence,
		};
		return { events: [...state.events, entry].slice(-12) };
	},
	view(state) {
		if (!state.events.length) return [];
		const lines = ["Recent activity:"];
		for (const e of state.events.slice(-6))
			lines.push(
				`- ${e.type}${e.label ? `: ${clip(e.label, 120)}` : ""}${e.error ? ` [error: ${clip(e.error, 80)}]` : ""}`
			);
		return lines;
	},
};

export const uncertainComponent = {
	name: "uncertain",
	initial: () => ({ open: new Map(), pending: [] }),
	reduce(state, event) {
		const a = activityOf(event);
		if (!a) return state;
		if (a.type === "tool.call")
			return { ...state, pending: [...state.pending, a.tool].slice(-32) };
		if (a.type !== "tool.result") return state;
		const tool = a.tool ?? state.pending[0] ?? null;
		const pending = a.tool ? state.pending : state.pending.slice(1);
		if (!tool) return { ...state, pending };
		const open = new Map(state.open);
		if (a.error) open.set(tool, clip(a.error, 120));
		else open.delete(tool);
		return { open, pending };
	},
	view(state) {
		if (!state.open.size) return [];
		return [
			`Unresolved tool errors (verify state before repeating): ${[...state.open].map(([tool, err]) => `${tool} → ${err}`).join("; ")}`,
		];
	},
};

/** Entity facts fold separately because they come from the Entity history. */
export const factsComponent = {
	name: "facts",
	initial: () => ({ active: new Map() }),
	reduce(state, event) {
		const d = event.data ?? {};
		if (event.type === "fact.asserted") {
			const active = new Map(state.active);
			active.set(d.record, {
				predicate: d.predicate,
				value: d.value,
				sequence: event.sequence,
			});
			return { active };
		}
		if (event.type === "fact.retracted") {
			// A retraction names the assertion it retracts by predicate, since
			// the record ID belongs to the event it points at.
			const active = new Map(state.active);
			for (const [record, fact] of active)
				if (fact.predicate === d.predicate) active.delete(record);
			return { active };
		}
		return state;
	},
	view(state, ctx = {}) {
		if (!state.active.size) return [];
		const lines = [`Known facts about ${ctx.projectEntity ?? "the project"}:`];
		for (const [, f] of [...state.active].slice(-10))
			lines.push(
				`- ${f.predicate}: ${clip(typeof f.value === "string" ? f.value : JSON.stringify(f.value), 160)}`
			);
		return lines;
	},
};

export const SESSION_COMPONENTS = [
	goalComponent,
	contextComponent,
	decisionsComponent,
	referencesComponent,
	recentComponent,
	uncertainComponent,
];

export function fold(components, events) {
	const states = new Map(components.map((c) => [c.name, c.initial()]));
	// Reducers are order-dependent -- a retraction only cancels an assertion it
	// follows -- while a bounded class read answers newest first. Fold in
	// sequence order regardless of the order the events were read in.
	const ordered = [...(events ?? [])].sort(
		(left, right) => (left?.sequence ?? 0) - (right?.sequence ?? 0)
	);
	for (const event of ordered)
		for (const component of components)
			states.set(
				component.name,
				component.reduce(states.get(component.name), event)
			);
	return states;
}

/**
 * Decisions read from another object's own `/decisions`. They are already that
 * object's rows, so there is nothing to de-duplicate and no shared table to
 * consult: a decision about an object lives on that object.
 */
export function priorDecisionsView(events, projectEntity) {
	if (!Array.isArray(events) || !events.length) return [];
	const outcomes = new Map();
	for (const event of events)
		if (event?.type === "decision.outcome" && event.data?.about_point != null)
			outcomes.set(event.data.about_point, event.data.outcome);
	const lines = [
		`Prior decisions recorded on ${projectEntity ?? "this object"}:`,
	];
	for (const event of events) {
		if (event?.type !== "decision.recorded") continue;
		const d = event.data ?? {};
		const outcome = outcomes.get(event.sequence);
		lines.push(
			`- ${d.record}: ${clip(d.choice, 120)} → ${outcome ? clip(outcome, 100) : "no outcome recorded"}`
		);
		if (lines.length > 6) break;
	}
	return lines.length > 1 ? lines : [];
}

/**
 * Renders the context block. `parts` is an ordered list of line arrays. The
 * block is trimmed to `budget` characters, dropping trailing sections first.
 */
export function renderContext({
	sessionId,
	projectEntity,
	tenant,
	parts,
	budget = 16000,
}) {
	const header = [
		"<lakeday-knowledge>",
		`Lakeday session: ${sessionId}${tenant ? ` (tenant ${tenant})` : ""}.${projectEntity ? ` Project entity: ${projectEntity}.` : ""}`,
		`Record a decision with entity_decide before finishing a turn that changes data, pipelines, dashboards, or code: id is the object the choice is about${projectEntity ? ` (${projectEntity} unless something else fits better)` : ""}, and data is {id: <short-kebab record id, never the session id>, actor_id, choice, rationale, alternatives, about: <this session>, evidence: [{object, point}]}. Attach measured results with entity_outcome on the same object, passing record_id.${projectEntity ? ` Record durable learnings with entity_fact on ${projectEntity}.` : ""}`,
	];
	const footer = ["</lakeday-knowledge>"];
	const sections = parts.filter((lines) => lines && lines.length);
	let body = [];
	for (const lines of sections) {
		const candidate = [...body, "", ...lines];
		if ([...header, ...candidate, ...footer].join("\n").length > budget) break;
		body = candidate;
	}
	return [...header, ...body, ...footer].join("\n");
}

export function projectSession({
	sessionEvents,
	factEvents,
	priorDecisions,
	sessionId,
	projectEntity,
	tenant,
	budget,
}) {
	const states = fold(SESSION_COMPONENTS, sessionEvents);
	const factState = fold([factsComponent], factEvents).get("facts");
	const ctx = { projectEntity };
	const parts = [
		goalComponent.view(states.get("goal"), ctx),
		contextComponent.view(states.get("context"), ctx),
		decisionsComponent.view(states.get("decisions"), ctx),
		uncertainComponent.view(states.get("uncertain"), ctx),
		priorDecisionsView(priorDecisions, projectEntity),
		factsComponent.view(factState, ctx),
		referencesComponent.view(states.get("references"), ctx),
		recentComponent.view(states.get("recent"), ctx),
	];
	return {
		states,
		text: renderContext({ sessionId, projectEntity, tenant, parts, budget }),
	};
}

/** Session context payload (replace semantics, like Agno's session context store). */
export function summarizeForContext(states, { reason, turnSummary } = {}) {
	const decisions = states.get("decisions");
	const references = states.get("references");
	const uncertain = states.get("uncertain");
	const goal = states.get("goal");
	return {
		reason: reason ?? "turn",
		goal: goal.goal ?? null,
		summary: clip(turnSummary ?? "", 1200),
		decisions: decisions.order.slice(-8).map((record) => {
			const d = decisions.byRecord.get(record);
			return {
				record,
				choice: clip(d.choice, 160),
				measured: d.outcomes.length > 0,
			};
		}),
		evidence: [...references.refs.values()]
			.slice(-10)
			.map(({ object, point }) => ({
				object,
				...(point === undefined ? {} : { point }),
			})),
		open: [...uncertain.open].map(([tool, err]) => `${tool}: ${err}`),
		updated_at: new Date().toISOString(),
	};
}

// --- ALWAYS enforcement ----------------------------------------------------

/**
 * Stop verdict. `turn` is a ledger of the current turn:
 *   { tools: [{ name, lakedayTool, kind, ok, label }], decisions, outcomes, nudges }
 */
export function stopVerdict(
	turn,
	{
		enforce = true,
		maxNudges = 1,
		stopActive = false,
		sessionId,
		projectEntity,
		surface = "mcp",
		openDecisions = 0,
		measuredAfterDecision = false,
	} = {}
) {
	if (!enforce) return { block: false };
	if (stopActive || (turn.nudges ?? turn.stopBlocks ?? 0) >= maxNudges)
		return { block: false, reason: "nudge budget exhausted" };
	const consequential = turn.tools.filter(
		(t) => t.kind === "consequential" && t.ok
	);
	const code = turn.tools.filter((t) => t.kind === "code");
	const needsDecision =
		(consequential.length > 0 || code.length >= 3) &&
		(turn.decisions ?? 0) === 0;
	const needsOutcome =
		openDecisions > 0 && measuredAfterDecision && (turn.outcomes ?? 0) === 0;
	if (!needsDecision && !needsOutcome) return { block: false };

	const lines = [
		"Lakeday ALWAYS policy: this turn is not finished until its knowledge is recorded.",
	];
	if (needsDecision) {
		const effects = [
			...consequential.map((t) => t.label),
			...(code.length ? [`${code.length} code edits`] : []),
		].slice(0, 6);
		lines.push(
			`You performed consequential actions without recording a decision: ${effects.join("; ")}.`,
			surface === "agent"
				? `Call session_decide with {id: <short-kebab record id>, object: <the object the decision is about>, choice: <what you did>, rationale: <why>, alternatives: [<what you rejected>], evidence: [{object: <table or object id>, point: <version or record if known>}]}${sessionId ? ` (the current session is ${sessionId})` : ""}.`
				: `Call entity_decide with id set to the object the decision is about${projectEntity ? ` (${projectEntity} unless something else fits better)` : ""}, and data {id: <short-kebab record id>, actor_id, choice: <what you did>, rationale: <why>, alternatives: [<what you rejected>], evidence: [{object: <table or object id>, point: <version or record if known>}]}. data.id names the decision, never the session${sessionId ? `; set about to ${sessionId} so it points back at this session` : ""}.`,
			"A decision is recorded on the object it is about. Use one decision per independent choice. Then finish your reply."
		);
	}
	if (needsOutcome)
		lines.push(
			surface === "agent"
				? `A prior decision${sessionId ? ` observed in session ${sessionId}` : ""} has no measured outcome, and this turn measured results. Call session_outcome with {record: <the decision's record id>, object: <the object it was recorded on>, outcome: <measured result>, evidence: [...]}.`
				: `A prior decision${sessionId ? ` observed in session ${sessionId}` : ""} has no measured outcome, and this turn measured results. Call entity_outcome with id set to the object the decision was recorded on, record_id set to the decision's record id, and data {actor_id, outcome: <measured result>, evidence: [{object, point}]}.`
		);
	lines.push(
		"If nothing consequential actually happened, say so explicitly in one sentence and finish; the policy will not block again this turn."
	);
	return { block: true, reason: lines.join("\n") };
}

// --- V8 harness integration ------------------------------------------------

/**
 * Folds one run's AG-UI events into a turn ledger the harness can pass to
 * `stopVerdict()`. Tool calls are matched by toolCallId across
 * TOOL_CALL_START / TOOL_CALL_ARGS / TOOL_CALL_RESULT.
 */
export function runLedger(events) {
	const calls = new Map();
	const order = [];
	let nudges = 0;
	let decisions = 0;
	let outcomes = 0;
	let decidedAt = -1;
	let measuredAfterDecision = false;
	for (const event of events ?? []) {
		switch (event.type) {
			case "TOOL_CALL_START":
				calls.set(event.toolCallId, { name: event.toolCallName, args: "" });
				order.push(event.toolCallId);
				break;
			case "TOOL_CALL_ARGS": {
				const call = calls.get(event.toolCallId);
				if (call) call.args += event.delta ?? "";
				break;
			}
			case "TOOL_CALL_RESULT": {
				const call = calls.get(event.toolCallId);
				if (!call) break;
				let input = {};
				try {
					input = JSON.parse(call.args || "{}");
				} catch {
					input = {};
				}
				const tool = normalizeToolCall({
					name: call.name,
					input,
					output: event.content,
				});
				const kind = classifyTool(tool);
				call.tool = {
					...tool,
					kind,
					ok: !tool.error,
					label: clip(toolEventData(tool).label, 120),
				};
				if (kind === "recording" && !tool.error) {
					if (knowledgeOperation(tool.lakedayTool) === "decide") {
						decisions++;
						decidedAt = order.indexOf(event.toolCallId);
					}
					if (knowledgeOperation(tool.lakedayTool) === "outcome") outcomes++;
				}
				if (
					kind === "measurement" &&
					decidedAt >= 0 &&
					order.indexOf(event.toolCallId) > decidedAt
				)
					measuredAfterDecision = true;
				break;
			}
			case "CUSTOM":
				if (event.name === "lakeday.learning.required") nudges++;
				break;
			default:
				break;
		}
	}
	const tools = order.map((id) => calls.get(id)?.tool).filter(Boolean);
	return { tools, decisions, outcomes, nudges, measuredAfterDecision };
}

/** Verdict for a V8 run about to finish. */
export function learningVerdict(
	events,
	{ learning, sessionId, openDecisions = 0 }
) {
	const mode = learning?.mode ?? "off";
	if (mode !== "always") return { block: false };
	const ledger = runLedger(events);
	return stopVerdict(ledger, {
		enforce: true,
		maxNudges: learning.maxNudges ?? 1,
		sessionId,
		surface: "agent",
		openDecisions,
		measuredAfterDecision: ledger.measuredAfterDecision,
	});
}

/**
 * Tardigrade components the harness appends when learning is enabled. They
 * render the run's ledger as instructions so the model sees what it has not
 * recorded yet; the harness itself enforces at run end.
 */
export function learningComponents(learning) {
	const mode = learning?.mode ?? "off";
	if (mode === "off") return [];
	return [
		{
			name: "learning_ledger",
			initial: () => ({ events: [] }),
			reduce: (state, event) =>
				[
					"TOOL_CALL_START",
					"TOOL_CALL_ARGS",
					"TOOL_CALL_RESULT",
					"CUSTOM",
				].includes(event.type)
					? { events: [...state.events, event] }
					: state,
			view(state) {
				const ledger = runLedger(state.events);
				const pending = ledger.tools
					.filter((t) => t.kind === "consequential" && t.ok)
					.map((t) => t.label);
				const lines = [
					mode === "always"
						? "Learning is ALWAYS on: every consequential action in this run must be followed by session_decide (object, choice, rationale, alternatives, evidence) before you finish; measured results after a decision need session_outcome; durable facts go to entity_fact."
						: "Learning tools are available: record consequential choices with session_decide, measured results with session_outcome, durable facts with entity_fact.",
				];
				if (pending.length && ledger.decisions === 0)
					lines.push(
						`Consequential actions not yet decided: ${pending.slice(0, 6).join("; ")}.`
					);
				if (ledger.nudges > 0)
					lines.push(
						"A learning reminder was already issued this run; record what applies, then finish."
					);
				return { instructions: lines.join("\n") };
			},
		},
	];
}

/** Tool factories for the V8 harness; `call` is the harness's component caller. */
export function learningTools(call, options = {}) {
	const reference = {
		type: "object",
		properties: {
			object: { type: "string", description: "The referenced object ID." },
			point: {
				type: "string",
				description:
					"Optional point in that object's history: a record ID or an event sequence.",
			},
		},
		required: ["object"],
		additionalProperties: false,
	};
	const object = (properties, required = Object.keys(properties)) => ({
		type: "object",
		properties,
		required,
		additionalProperties: false,
	});
	/** Routes a write to the object it belongs on; the session is one object. */
	const route = (env, id, sessionId) =>
		id === sessionId
			? env.SESSION.getByName(sessionId)
			: env.ENTITY.getByName(id);
	const target = {
		type: "string",
		description:
			"The object the decision is recorded on; defaults to the project entity, otherwise this session.",
	};
	const tools = [
		{
			name: "session_decide",
			description:
				"Record an immutable decision on the object it is about: what you chose, why, what you rejected, and the evidence (objects, optionally at a version or record).",
			parameters: object(
				{
					id: { type: "string" },
					object: target,
					choice: { type: "string" },
					rationale: { type: "string" },
					alternatives: { type: "array", items: { type: "string" } },
					evidence: { type: "array", items: reference },
				},
				["id", "choice", "rationale"]
			),
			replay: "idempotent",
			execute: (
				{ object: about, ...args },
				{ env, actorId, sessionId, userEntityId, idempotencyKey }
			) =>
				call(
					route(env, about ?? userEntityId ?? sessionId, sessionId),
					"/decisions",
					{ ...args, actor_id: actorId },
					idempotencyKey
				),
		},
		{
			name: "session_outcome",
			description:
				"Attach a measured outcome to an earlier decision, addressed by the record ID it claimed on the object it was recorded on.",
			parameters: object(
				{
					record: { type: "string" },
					object: target,
					outcome: { type: "string" },
					evidence: { type: "array", items: reference },
				},
				["record", "outcome"]
			),
			replay: "idempotent",
			execute: (
				{ record, object: about, ...args },
				{ env, actorId, sessionId, userEntityId, idempotencyKey }
			) =>
				call(
					route(env, about ?? userEntityId ?? sessionId, sessionId),
					`/decisions/${encodeURIComponent(record)}/outcomes`,
					{ ...args, actor_id: actorId },
					idempotencyKey
				),
		},
		{
			name: "entity_fact",
			description:
				"Remember an attributed, retractable fact about an object (the current user by default): baselines, root causes, owners, learnings.",
			parameters: object(
				{
					id: { type: "string" },
					predicate: { type: "string" },
					value: { type: "string" },
					entity: {
						type: "string",
						description: "Object ID; defaults to the current user object.",
					},
					evidence: { type: "array", items: reference },
				},
				["id", "predicate", "value"]
			),
			replay: "idempotent",
			execute: (
				{ entity, evidence, ...args },
				{ env, actorId, userEntityId, sessionId, idempotencyKey }
			) =>
				call(
					env.ENTITY.getByName(entity ?? userEntityId),
					"/facts",
					{
						...args,
						actor_id: actorId,
						// The session that observed the fact is cited, not copied.
						evidence: [
							...(evidence ?? []),
							...(sessionId ? [{ object: sessionId }] : []),
						].slice(0, 32),
					},
					idempotencyKey
				),
		},
		{
			name: "entity_link",
			description:
				"Record a typed link from one object to another; the link names the other object's ID.",
			parameters: object({
				entity: { type: "string" },
				id: { type: "string" },
				predicate: { type: "string" },
				about: { type: "string" },
			}),
			replay: "idempotent",
			execute: (
				{ entity, ...args },
				{ env, actorId, sessionId, idempotencyKey }
			) =>
				call(
					env.ENTITY.getByName(entity),
					"/links",
					{
						...args,
						actor_id: actorId,
						...(sessionId ? { evidence: [{ object: sessionId }] } : {}),
					},
					idempotencyKey
				),
		},
	];
	const skip = new Set(options.existing ?? []);
	return tools.filter((tool) => !skip.has(tool.name));
}
