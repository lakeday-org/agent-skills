import type { LearningMode, LearningOptions } from "./learning";
/** A component binding executes in the agent's granted Worker stack. */
export interface AgentBinding {
	fetch(input: Request | string, init?: RequestInit): Promise<Response>;
}
export interface AgentNamespace {
	getByName(name: string): AgentBinding;
}
export interface AgentEnvironment {
	/** Explicit Worker secret bindings. */
	[name: string]: unknown;
	CODEX: AgentBinding & { owner(): string | null; permissions(): string[] };
	AGENT_STATE: AgentNamespace;
	AGENT_AUTH: AgentNamespace;
	ENTITY: AgentNamespace;
	SESSION: AgentNamespace;
	QUERY?: AgentBinding;
	SINK?: { upsert(batch: unknown): Promise<unknown> };
	JSX?: AgentBinding;
	UI: {
		command(value: unknown): unknown;
		render(request: Request, document: unknown): Promise<Response>;
	};
}
export interface AgentToolContext {
	env: AgentEnvironment;
	actorId: string;
	userEntityId: string;
	sessionId: string;
	runId: string;
	/** Reuse this identity for every downstream mutation so recovery cannot duplicate effects. */
	idempotencyKey: string;
}
export interface AgentTool {
	/** Additional live grant required by a native product effect. */
	permission?: "lakeday:agent:sink";
	name: string;
	description: string;
	parameters: Record<string, unknown> & { type: "object" };
	/** Idempotent tools must honor context.idempotencyKey at their effect boundary. */
	replay: "read" | "idempotent";
	execute(
		arguments_: Record<string, unknown>,
		context: AgentToolContext
	): Promise<unknown> | unknown;
}
/** A pure state machine whose rendered view follows the immutable Session events. */
export interface AgentComponent {
	name: string;
	initial(): Record<string, unknown>;
	reduce(
		state: Record<string, unknown>,
		event: Record<string, unknown>
	): Record<string, unknown>;
	view(state: Record<string, unknown>): {
		instructions?: string;
		tools?: string[];
		stop?: string;
	};
}
/** Rebuilds component state without executing model or tool effects. */
export function projectAgentComponents(
	components: AgentComponent[],
	events: Record<string, unknown>[]
): { instructions: string; tools?: string[]; stop?: string };
export interface AgentDefinition {
	/**
	 * Learning one-liner. "always" appends session_decide, session_outcome,
	 * entity_fact, and entity_link (unless authored), projects the Session's
	 * durable history into working memory, and sends a finishing run back
	 * once when it performed consequential actions without a decision.
	 * "agentic" adds the tools and instructions without enforcement.
	 */
	learning?: LearningMode | LearningOptions;
	components?: AgentComponent[];
	/** Stable personal agent Entity suffix, distinct for custom agents. */
	name?: string;
	instructions: string;
	model: string;
	maxSteps?: number;
	tools?: AgentTool[];
}
export interface AgentStorage {
	get(key: string): Promise<unknown>;
	put(key: string, value: unknown): Promise<void>;
	delete(key: string): Promise<unknown>;
	lance(command: string): Promise<string>;
}
export interface AgentObject {
	fetch(request: Request): Promise<Response>;
}
export function defineAgent(
	definition: AgentDefinition
): Readonly<AgentDefinition>;
export function createAgentRuntime(definition: AgentDefinition): {
	worker: {
		fetch(request: Request, environment: AgentEnvironment): Promise<Response>;
	};
	AgentState: new (
		state: { storage: AgentStorage; id: { toString(): string } },
		env: AgentEnvironment
	) => AgentObject;
	AgentAuth: new (
		state: { storage: AgentStorage; id: { toString(): string } },
		env: AgentEnvironment
	) => AgentObject;
};
export function codexEvents(
	response: Response
): AsyncGenerator<Record<string, unknown>>;
export function agentManifest(
	name: string,
	bindings?: string[]
): {
	name: string;
	main: string;
	lakeday: { agent: { name: string; provider: string } };
	artifacts: { worker: Record<string, never> };
	services: Array<{ binding: string; service: string }>;
	durable_objects: { bindings: Array<{ name: string; class_name: string }> };
};
