export type CollectionOperation = "read" | "write" | "manage";
export type CollectionRole =
	| "collection-reader"
	| "collection-writer"
	| "collection-manager";
export interface DataCollection {
	id: string;
	name: string;
	permissions: CollectionOperation[];
}
export interface DataSource {
	lake_namespace: string;
	worker: string;
	binding: string;
	object: string;
	source_name?: string | null;
	parent_worker?: string | null;
}
export type DataSourceInput =
	| Omit<DataSource, "source_name">
	| {
			lake_namespace: string;
			worker: "system";
			binding: "ENTITY" | "SESSION" | "STREAM";
			source_name: string;
	  };
export interface TablePolicy {
	lake_namespace: string;
	table_namespace: string[];
	table_name: string;
	sql_alias: string;
	row_user_column: string | null;
}
export type CollectionGrant = { role: CollectionRole } & (
	| { membership_id: string }
	| { email: string }
);
export interface AccessTokenInput {
	name: string;
	permissions: string[];
	expiresAt?: string | null;
}
export interface AccessClient {
	listCollections(
		tenant: string
	): Promise<{ collections: DataCollection[]; can_create: boolean }>;
	createCollection(
		tenant: string,
		input: { id: string; name: string }
	): Promise<{ collection: DataCollection }>;
	listGrants(
		tenant: string,
		collection: string
	): Promise<{
		grants: Array<{
			permission: CollectionOperation;
			memberships: Array<{ id: string; userId: string }>;
		}>;
	}>;
	grant(
		tenant: string,
		collection: string,
		input: CollectionGrant
	): Promise<{ updated: boolean }>;
	revoke(
		tenant: string,
		collection: string,
		input: CollectionGrant
	): Promise<{ updated: boolean }>;
	listSources(
		tenant: string,
		collection: string
	): Promise<{ sources: DataSource[] }>;
	assignSource(
		tenant: string,
		collection: string,
		input: DataSourceInput
	): Promise<{ created: boolean }>;
	listTables(
		tenant: string,
		collection: string
	): Promise<{ tables: TablePolicy[] }>;
	setTablePolicy(
		tenant: string,
		collection: string,
		input: TablePolicy
	): Promise<{ updated: boolean }>;
	roles(
		organization: string
	): Promise<{
		roles: Array<{ slug: string; name: string; permissions: string[] }>;
		permissions: string[];
		token_permissions: string[];
		token_owner: string;
	}>;
	listTokens(
		organization: string
	): Promise<{
		tokens: Array<{
			id: string;
			name: string;
			owner: string;
			permissions: string[];
			expiresAt: string | null;
		}>;
	}>;
	createToken(
		organization: string,
		input: AccessTokenInput
	): Promise<{
		token: { id: string; value: string; owner: string; permissions: string[] };
	}>;
	revokeToken(organization: string, id: string): Promise<{ revoked: boolean }>;
}
export function createAccessClient(options: {
	origin?: string;
	token: string;
	fetch?: typeof globalThis.fetch;
}): AccessClient;
