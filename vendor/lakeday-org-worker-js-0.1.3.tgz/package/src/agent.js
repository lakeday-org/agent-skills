/** Native Worker agent orchestration. Session events are durable; credentials come from Worker secrets or private auth storage. */
import {
	learningComponents,
	learningTools,
	learningVerdict,
	normalizeLearning,
	projectSession,
	runLedger,
} from "./learning.js";
const ID = /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/;
const OWNER = /^os:[a-f0-9]{64}:user$/;
const CLIENT = "app_EMoamEEZ73f0CkXaXp7hrann";
const AUTH = "https://auth.openai.com";
const MAX_BODY = 16384;
const MAX_CONTEXT = 120000;
const MAX_EVENTS = 2048;

/** Public error with no provider credentials or upstream response bodies. */
class AgentError extends Error {
	constructor(status, message) {
		super(message);
		this.status = status;
	}
}

/** Agent checkpoints span bounded KV values; one batch publishes their changed pages atomically. */
class AgentCheckpointStorage {
	constructor(storage) {
		this.storage = storage;
		this.pages = new Map();
		this.roots = new Map();
	}
	managed(key) {
		return key === "messages" || key.startsWith("run:");
	}
	pageKey(key, field, index) {
		return `checkpoint:${key}:${field}:${index}`;
	}
	async get(key) {
		if (!this.managed(key)) return this.storage.get(key);
		for (let attempt = 0; attempt < 3; attempt++) {
			const root = await this.storage.get(key);
			if (root?.$agentCheckpoint !== 1) {
				this.roots.set(key, root);
				return root;
			}
			const value = { ...root.data };
			let missing = false;
			for (const [field, count] of Object.entries(root.pages)) {
				let encoded = "";
				for (let index = 0; index < count; index++) {
					const pageKey = this.pageKey(key, field, index);
					const page = await this.storage.get(pageKey);
					if (typeof page !== "string") {
						missing = true;
						break;
					}
					this.pages.set(pageKey, JSON.stringify(page));
					encoded += page;
				}
				if (!missing) value[field] = encoded;
			}
			// A concurrent atomic checkpoint may replace/delete pages between reads.
			const current = await this.storage.get(key);
			if (current?.revision !== root.revision) continue;
			if (missing) throw new AgentError(503, "Agent checkpoint is incomplete");
			for (const field of Object.keys(root.pages))
				value[field] = JSON.parse(value[field]);
			this.roots.set(key, root);
			return key === "messages" ? value.value : value;
		}
		throw new AgentError(
			409,
			"Agent checkpoint changed during read; resume the turn"
		);
	}
	async expand(puts, deletes) {
		const expanded = { ...puts };
		const removed = [...deletes];
		const roots = new Map();
		for (const [key, encoded] of Object.entries(puts)) {
			if (!this.managed(key)) continue;
			const previous = this.roots.has(key)
				? this.roots.get(key)
				: await this.storage.get(key);
			if (
				new TextEncoder().encode(encoded).length <= 48 * 1024 &&
				previous?.$agentCheckpoint !== 1
			)
				continue;
			const value = JSON.parse(encoded);
			const root = {
				$agentCheckpoint: 1,
				revision: (previous?.revision ?? 0) + 1,
				data: {},
				pages: {},
			};
			for (const [field, item] of Object.entries(
				key === "messages" ? { value } : value
			)) {
				const text = JSON.stringify(item);
				if (text.length <= 4096) {
					root.data[field] = item;
					continue;
				}
				// 16K UTF-16 units stay below 128 KiB even after JSON escaping.
				root.pages[field] = Math.ceil(text.length / 16384);
				for (let index = 0; index < root.pages[field]; index++) {
					const pageKey = this.pageKey(key, field, index);
					const page = JSON.stringify(
						text.slice(index * 16384, (index + 1) * 16384)
					);
					if (this.pages.get(pageKey) !== page) expanded[pageKey] = page;
				}
			}
			for (const [field, count] of Object.entries(previous?.pages ?? {})) {
				for (let index = root.pages[field] ?? 0; index < count; index++)
					removed.push(this.pageKey(key, field, index));
			}
			expanded[key] = JSON.stringify(root);
			roots.set(key, root);
		}
		return { puts: expanded, deletes: removed, roots };
	}
	async lance(raw) {
		const command = JSON.parse(raw);
		if (command.op !== "kv.batch") return this.storage.lance(raw);
		const expanded = await this.expand(command.args.puts, command.args.deletes);
		const args = {
			...command.args,
			puts: expanded.puts,
			deletes: expanded.deletes,
		};
		if (
			args.checks.length + Object.keys(args.puts).length + args.deletes.length >
				128 ||
			new TextEncoder().encode(JSON.stringify(args)).length > 1024 * 1024
		)
			throw new AgentError(
				413,
				"Agent checkpoint update exceeds storage transaction limit"
			);
		const result = await this.storage.lance(
			JSON.stringify({ op: "kv.batch", args })
		);
		if (JSON.parse(result)) {
			for (const [key, value] of Object.entries(expanded.puts))
				this.pages.set(key, value);
			for (const key of expanded.deletes) this.pages.delete(key);
			for (const [key, root] of expanded.roots) this.roots.set(key, root);
		}
		return result;
	}
	async put(key, value) {
		if (!this.managed(key)) return this.storage.put(key, value);
		const encoded = JSON.stringify(value);
		if (
			new TextEncoder().encode(encoded).length <= 48 * 1024 &&
			this.roots.get(key)?.$agentCheckpoint !== 1
		)
			return this.storage.put(key, value);
		await this.lance(
			JSON.stringify({
				op: "kv.batch",
				args: { checks: [], puts: { [key]: encoded }, deletes: [] },
			})
		);
	}
}
/** Requires bounded JSON input before it enters persistent state. */
async function jsonBody(request) {
	const reader = request.body?.getReader();
	const decoder = new TextDecoder();
	let text = reader ? "" : await request.text();
	let bytes = 0;
	if (reader)
		try {
			for (;;) {
				const chunk = await reader.read();
				if (chunk.done) {
					text += decoder.decode();
					break;
				}
				bytes += chunk.value.length;
				if (bytes > MAX_BODY)
					throw new AgentError(413, "Agent input exceeds 16 KiB");
				text += decoder.decode(chunk.value, { stream: true });
			}
		} finally {
			await reader.cancel();
		}
	if (new TextEncoder().encode(text).length > MAX_BODY)
		throw new AgentError(413, "Agent input exceeds 16 KiB");
	let value;
	try {
		value = JSON.parse(text);
	} catch {
		throw new AgentError(400, "Expected a JSON object");
	}
	if (!value || typeof value !== "object" || Array.isArray(value))
		throw new AgentError(400, "Expected a JSON object");
	return value;
}
/** Reads the native verified principal, never a user-supplied actor or header. */
function principal(env) {
	const owner = env.CODEX?.owner();
	if (!OWNER.test(owner ?? ""))
		throw new AgentError(401, "A signed-in Lakeday user is required");
	return owner;
}
/** Reuses a durable completion receipt; opening chat does not rewrite Entities. */
async function ensureProfile(env, owner) {
	const response = await env.AGENT_AUTH.getByName("auth:" + owner).fetch(
		new Request("https://agent/profile", { method: "POST" })
	);
	if (!response.ok)
		throw new AgentError(503, "Personal Entity provisioning is unavailable");
	return response.json();
}
/** Creates missing identities and their ownership link before recording completion. */
async function provisionProfile(env, owner, name = "default") {
	const agentEntityId = owner.slice(0, -4) + "agent:" + name;
	await Promise.all(
		[
			[owner, "user", "Lakeday user"],
			[agentEntityId, "agent", "Cloud agent"],
		].map(async ([id, kind, label]) => {
			const stub = env.ENTITY.getByName(id);
			const existing = await stub.fetch("https://object/");
			if (existing.status === 404) {
				const created = await stub.fetch("https://object/", {
					method: "POST",
					headers: {
						"content-type": "application/json",
						"idempotency-key": "agent-profile",
					},
					body: JSON.stringify({ kind, name: label, actor_id: owner }),
				});
				if (!created.ok)
					throw new AgentError(
						503,
						"Personal Entity provisioning is unavailable"
					);
			} else if (!existing.ok)
				throw new AgentError(503, "Personal Entity is unavailable");
		})
	);
	const linked = await env.ENTITY.getByName(agentEntityId).fetch(
		"https://object/links",
		{
			method: "POST",
			headers: {
				"content-type": "application/json",
				"idempotency-key": "agent-owner",
			},
			body: JSON.stringify({
				id: "owner",
				actor_id: owner,
				predicate: "owned_by",
				about: owner,
			}),
		}
	);
	if (!linked.ok)
		throw new AgentError(503, "Agent ownership could not be recorded");
	return { userEntityId: owner, agentEntityId };
}
/** Reads bounded event-derived working memory; unavailable storage stops inference. */
async function readMemory(env, profile, sessionId, learning) {
	const records = {};
	for (const [key, stub, path] of [
		[
			"userFacts",
			env.ENTITY.getByName(profile.userEntityId),
			"/facts?limit=30",
		],
		[
			"agentFacts",
			env.ENTITY.getByName(profile.agentEntityId),
			"/facts?limit=20",
		],
		["session", env.SESSION.getByName(sessionId), "/"],
		["decisions", env.SESSION.getByName(sessionId), "/decisions?limit=20"],
	]) {
		let readPath = path;
		if (key === "userFacts" || key === "agentFacts") {
			const head = await stub.fetch("https://object/");
			if (!head.ok) throw new AgentError(503, "Entity memory is unavailable");
			const sequence = (await head.json()).sequence ?? 0;
			readPath +=
				"&after=" + Math.max(0, sequence - (key === "userFacts" ? 30 : 20));
		}
		const response = await stub.fetch("https://object" + readPath);
		if (!response.ok) throw new AgentError(503, "Agent memory is unavailable");
		const value = await response.json();
		records[key] =
			JSON.stringify(value).length <= 5000
				? value
				: {
						notice:
							"Memory page exceeds context budget; use knowledge_read with pagination.",
					};
	}
	if (learning && learning.mode !== "off") {
		// Tardigrade projection: the session object's own history folded into a
		// bounded context block, rebuilt before every run. Prior decisions are
		// read from the project object's own rows, never a cross-object index.
		const stub = env.SESSION.getByName(sessionId);
		const sequence = records.session?.sequence ?? 0;
		const response = await stub.fetch(
			"https://object/history?limit=100&after=" + Math.max(0, sequence - 100)
		);
		if (!response.ok)
			throw new AgentError(503, "Session history is unavailable");
		const history = await response.json();
		const prior = await env.ENTITY.getByName(profile.userEntityId).fetch(
			"https://object/decisions?limit=20"
		);
		if (!prior.ok)
			throw new AgentError(503, "Project decisions are unavailable");
		records.projection = projectSession({
			sessionEvents: history.events ?? [],
			factEvents: records.userFacts?.events ?? [],
			priorDecisions: (await prior.json()).events ?? [],
			sessionId,
			projectEntity: profile.userEntityId,
			budget: learning.budget,
		}).text;
	}
	return records;
}
/** Selects only the current user's explicit Worker-secret credential. */
function secretCredential(env, owner) {
	const prefix = "USER_" + owner.slice(3, 67) + "_";
	const apiKey = env[prefix + "OPENAI_API_KEY"];
	const token = env[prefix + "OPENAI_OAUTH_TOKEN"];
	if (apiKey && token)
		throw new AgentError(
			409,
			"Keep one OpenAI credential: an API key or OAuth token"
		);
	if (typeof apiKey === "string" && apiKey.trim())
		return {
			access: apiKey,
			provider: "openai",
			source: "worker_secret",
			expires: Infinity,
		};
	if (typeof token === "string" && token.trim()) {
		let claims;
		try {
			claims = JSON.parse(
				atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))
			);
		} catch {
			throw new AgentError(400, "OAuth secret must be a Codex access token");
		}
		const accountId = claims["https://api.openai.com/auth"]?.chatgpt_account_id;
		if (typeof accountId !== "string" || !accountId)
			throw new AgentError(400, "OAuth secret has no Codex account identity");
		return {
			access: token,
			accountId,
			provider: "openai-codex",
			source: "worker_secret",
			expires: typeof claims.exp === "number" ? claims.exp * 1000 : Infinity,
		};
	}
	return null;
}
/** Calls a granted component and preserves its actual failure. */
async function componentCall(binding, path, body, key) {
	if (!binding?.fetch)
		throw new Error("Required component binding is not granted");
	const response = await binding.fetch("https://component.internal" + path, {
		method: body === undefined ? "GET" : "POST",
		headers: {
			"content-type": "application/json",
			...(key ? { "idempotency-key": key } : {}),
		},
		...(body === undefined ? {} : { body: JSON.stringify(body) }),
	});
	if (!response.ok && ![400, 403, 404, 409, 422].includes(response.status))
		throw new Error(`Component returned HTTP ${response.status}`);
	return response.json();
}
/** Renders a harness from immutable events. Components narrow tools by intersection. */
export function projectAgentComponents(components, events) {
	const instructions = [];
	let tools;
	let stop;
	for (const component of components) {
		const state = events.reduce(
			(state, event) => component.reduce(state, event),
			component.initial()
		);
		const view = component.view(state);
		if (typeof view.instructions === "string")
			instructions.push(view.instructions);
		if (Array.isArray(view.tools))
			tools =
				tools === undefined
					? [...view.tools]
					: tools.filter((name) => view.tools.includes(name));
		if (view.stop) stop = String(view.stop).slice(0, 512);
	}
	return {
		instructions: instructions.join("\n"),
		...(tools === undefined ? {} : { tools }),
		...(stop ? { stop } : {}),
	};
}
/** Bounded ledger of one run for the Session context (replace semantics). */
function contextLedger(events) {
	const ledger = runLedger(events);
	return {
		decisions: ledger.decisions,
		outcomes: ledger.outcomes,
		effects: ledger.tools
			.filter((tool) => tool.kind === "consequential" && tool.ok)
			.map((tool) => tool.label)
			.slice(0, 12),
	};
}
/** Retains complete turns; the full audit log remains in the native Session. */
function conversationTail(messages) {
	let retained = messages;
	while (JSON.stringify(retained).length > 48000) {
		const next = retained.findIndex(
			(message, index) => index > 0 && message.role === "user"
		);
		retained = next < 0 ? [] : retained.slice(next);
	}
	return retained;
}
/** Validates an author-supplied agent and its explicit replay contracts. */
export function defineAgent(definition) {
	if (
		!definition ||
		typeof definition.instructions !== "string" ||
		!definition.instructions.trim() ||
		definition.instructions.length > 16384
	)
		throw new TypeError("Agent instructions must contain 1..16384 characters");
	if (
		typeof definition.model !== "string" ||
		!/^[a-zA-Z0-9_.-]{1,100}$/.test(definition.model)
	)
		throw new TypeError("Agent model is required");
	if (
		definition.name !== undefined &&
		!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,39}$/.test(definition.name)
	)
		throw new TypeError("Invalid agent identity name");
	const maxSteps = definition.maxSteps ?? 16;
	if (!Number.isInteger(maxSteps) || maxSteps < 1 || maxSteps > 64)
		throw new TypeError("maxSteps must be 1..64");
	const components = definition.components ?? [];
	if (
		!Array.isArray(components) ||
		components.length > 16 ||
		components.some(
			(component) =>
				typeof component.name !== "string" ||
				typeof component.initial !== "function" ||
				typeof component.reduce !== "function" ||
				typeof component.view !== "function"
		)
	)
		throw new TypeError(
			"Agent components require name, initial, reduce, and view"
		);
	const learning = normalizeLearning(definition.learning);
	const authored = definition.tools ?? [];
	if (!Array.isArray(authored))
		throw new TypeError("Agent tools must be an array");
	// The learning one-liner: mode "always" or "agentic" appends the
	// knowledge tools the author did not define and a ledger component.
	const tools =
		learning.mode === "off"
			? authored
			: [
					...authored,
					...learningTools(componentCall, {
						existing: authored.map((tool) => tool?.name),
					}),
				];
	if (!Array.isArray(tools) || tools.length > 64)
		throw new TypeError("At most 64 tools are supported");
	const names = new Set();
	for (const tool of tools) {
		if (!/^[a-zA-Z0-9_-]{1,64}$/.test(tool.name) || names.has(tool.name))
			throw new TypeError("Tool names must be unique portable identifiers");
		names.add(tool.name);
		validateSchema(tool.parameters);
		if (!["read", "idempotent"].includes(tool.replay))
			throw new TypeError(
				`Tool ${tool.name} must declare replay: read or idempotent`
			);
		if (
			typeof tool.execute !== "function" ||
			(tool.permission !== undefined &&
				tool.permission !== "lakeday:agent:sink") ||
			typeof tool.description !== "string" ||
			tool.parameters?.type !== "object"
		)
			throw new TypeError(
				`Tool ${tool.name} needs execute, description, and object parameters`
			);
	}
	return Object.freeze({
		...definition,
		maxSteps,
		learning,
		components: Object.freeze([...components, ...learningComponents(learning)]),
		tools: Object.freeze([...tools]),
	});
}
/** Validates the portable tool-schema subset without compiling or evaluating model-provided code. */
function validateArguments(schema, value, path = "arguments", depth = 0) {
	if (depth > 16)
		throw new AgentError(400, "Tool arguments are too deeply nested");
	const type = schema.type;
	const valid =
		type === undefined ||
		(type === "object"
			? value !== null && typeof value === "object" && !Array.isArray(value)
			: type === "array"
				? Array.isArray(value)
				: type === "integer"
					? Number.isSafeInteger(value)
					: type === "null"
						? value === null
						: typeof value === type);
	if (!valid || (schema.enum && !schema.enum.includes(value)))
		throw new AgentError(400, `Invalid tool ${path}`);
	if (
		typeof value === "number" &&
		(!Number.isFinite(value) ||
			value < (schema.minimum ?? -Infinity) ||
			value > (schema.maximum ?? Infinity))
	)
		throw new AgentError(400, `Tool ${path} is outside its bounds`);
	if (
		typeof value === "string" &&
		(value.length < (schema.minLength ?? 0) ||
			value.length > (schema.maxLength ?? 16384))
	)
		throw new AgentError(400, `Tool ${path} is outside its bounds`);
	if (Array.isArray(value)) {
		if (
			value.length < (schema.minItems ?? 0) ||
			value.length > (schema.maxItems ?? 1024)
		)
			throw new AgentError(400, `Tool ${path} is outside its bounds`);
		if (schema.items)
			value.forEach((v, i) =>
				validateArguments(schema.items, v, `${path}.${i}`, depth + 1)
			);
	} else if (value && typeof value === "object") {
		for (const key of schema.required ?? [])
			if (!Object.hasOwn(value, key))
				throw new AgentError(400, `Tool ${path}.${key} is required`);
		for (const [key, v] of Object.entries(value)) {
			if (["__proto__", "prototype", "constructor"].includes(key))
				throw new AgentError(400, "Unsafe tool property");
			if (Object.hasOwn(schema.properties ?? {}, key))
				validateArguments(
					schema.properties[key],
					v,
					`${path}.${key}`,
					depth + 1
				);
			else if (schema.additionalProperties === false)
				throw new AgentError(400, `Unknown tool ${path}.${key}`);
		}
	}
}
/** Rejects schema features the native validator does not implement. */
function validateSchema(schema, depth = 0) {
	if (
		!schema ||
		typeof schema !== "object" ||
		Array.isArray(schema) ||
		depth > 16
	)
		throw new TypeError("Invalid tool schema");
	for (const key of Object.keys(schema))
		if (
			![
				"type",
				"description",
				"title",
				"properties",
				"required",
				"additionalProperties",
				"items",
				"enum",
				"minimum",
				"maximum",
				"minLength",
				"maxLength",
				"minItems",
				"maxItems",
			].includes(key)
		)
			throw new TypeError(`Unsupported tool schema keyword: ${key}`);
	if (
		schema.type !== undefined &&
		![
			"object",
			"array",
			"integer",
			"number",
			"string",
			"boolean",
			"null",
		].includes(schema.type)
	)
		throw new TypeError("Unsupported tool schema type");
	if (
		schema.additionalProperties !== undefined &&
		typeof schema.additionalProperties !== "boolean"
	)
		throw new TypeError("additionalProperties must be boolean");
	if (
		schema.required &&
		(!Array.isArray(schema.required) ||
			schema.required.some((v) => typeof v !== "string"))
	)
		throw new TypeError("required must contain property names");
	for (const child of Object.values(schema.properties ?? {}))
		validateSchema(child, depth + 1);
	if (schema.items) validateSchema(schema.items, depth + 1);
}
/** Parses bounded SSE frames across arbitrary byte and UTF-8 boundaries. */
export async function* codexEvents(response) {
	if (!response.body) throw new AgentError(502, "Codex returned no stream");
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	let completed = false;
	try {
		for (;;) {
			const chunk = await reader.read();
			if (!chunk.done && chunk.value?.length === 0) {
				yield { type: "lakeday.keepalive" };
				continue;
			}
			buffer += decoder.decode(chunk.value ?? new Uint8Array(), {
				stream: !chunk.done,
			});
			if (buffer.length > 1024 * 1024)
				throw new AgentError(502, "Codex frame exceeds 1 MiB");
			for (;;) {
				const boundary = /\r?\n\r?\n/.exec(buffer);
				if (!boundary) break;
				const frame = buffer.slice(0, boundary.index);
				buffer = buffer.slice(boundary.index + boundary[0].length);
				const data = frame
					.split(/\r?\n/)
					.filter((line) => line.startsWith("data:"))
					.map((line) => line.slice(5).trimStart())
					.join("\n");
				if (!data) {
					if (frame.startsWith(":")) yield { type: "lakeday.keepalive" };
					continue;
				}
				if (data === "[DONE]") continue;
				let event;
				try {
					event = JSON.parse(data);
				} catch {
					throw new AgentError(502, "Invalid Codex event");
				}
				if (
					event.type === "response.failed" ||
					event.type === "error" ||
					event.type === "response.incomplete"
				)
					throw new AgentError(502, "Codex could not complete this response");
				if (event.type === "response.completed") completed = true;
				yield event;
			}
			if (chunk.done || completed) break;
		}
		if (!completed)
			throw new AgentError(502, "Codex stream ended before response.completed");
	} finally {
		await reader.cancel();
	}
}
/** Encodes AG-UI events lazily so the runtime can apply response backpressure. */
function eventResponse(iterator) {
	const encoder = new TextEncoder();
	return new Response(
		new ReadableStream({
			async pull(controller) {
				const next = await iterator.next();
				if (next.done) controller.close();
				else
					controller.enqueue(
						encoder.encode(`data: ${JSON.stringify(next.value)}\n\n`)
					);
			},
			async cancel() {
				await iterator.return?.();
			},
		}),
		{
			headers: {
				"content-type": "text/event-stream",
				"cache-control": "no-store",
				"x-accel-buffering": "no",
			},
		}
	);
}
/** Encodes OAuth forms without depending on Node or URLSearchParams extensions. */
function form(fields) {
	return Object.entries(fields)
		.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
		.join("&");
}
/** Converts a validated OAuth response into private credential state. */
function credentials(value) {
	if (
		typeof value.access_token !== "string" ||
		typeof value.refresh_token !== "string" ||
		!Number.isFinite(value.expires_in) ||
		value.expires_in <= 0
	)
		throw new AgentError(502, "Invalid Codex token response");
	let accountId;
	try {
		const payload = value.access_token
			.split(".")[1]
			.replace(/-/g, "+")
			.replace(/_/g, "/");
		accountId = JSON.parse(atob(payload))["https://api.openai.com/auth"]
			.chatgpt_account_id;
	} catch {
		throw new AgentError(502, "Codex token has no account identity");
	}
	if (typeof accountId !== "string" || !accountId)
		throw new AgentError(502, "Codex token has no account identity");
	return {
		access: value.access_token,
		refresh: value.refresh_token,
		expires: Date.now() + value.expires_in * 1000,
		accountId,
	};
}
/** Calls the narrow native Codex HTTP binding, which pins destinations and forbids redirects. */
async function oauth(env, path, body, encoded = false) {
	const response = await env.CODEX.fetch(AUTH + path, {
		method: "POST",
		headers: {
			"content-type": encoded
				? "application/x-www-form-urlencoded"
				: "application/json",
		},
		body: encoded ? form(body) : JSON.stringify(body),
	});
	if (!response.ok) {
		await response.body?.getReader().cancel();
		throw new AgentError(
			response.status === 429 ? 429 : 502,
			`Codex authorization failed (HTTP ${response.status})`
		);
	}
	return response.json();
}
/** Builds identical Worker and DO exports for the default agent and user-authored agents. */
export function createAgentRuntime(input) {
	const definition = defineAgent(input);
	class AgentAuth {
		constructor(state, env) {
			this.storage = state.storage;
			this.env = env;
		}
		/** Serializes credential rotation and prevents cross-user access to a named auth object. */
		async fetch(request) {
			const owner = principal(this.env);
			if (
				new URL(request.url).pathname === "/profile" &&
				request.method === "POST"
			) {
				const key = "profile:" + (definition.name ?? "default");
				const completed = await this.storage.get(key);
				if (completed) return Response.json(completed);
				const profile = await provisionProfile(
					this.env,
					owner,
					definition.name ?? "default"
				);
				await this.storage.put(key, profile);
				return Response.json(profile);
			}
			if (request.method !== "POST") return this.route(request);
			const raw = JSON.parse(
				await this.storage.lance(
					JSON.stringify({ op: "kv.get", args: { key: "auth-lease" } })
				)
			);
			if (raw && JSON.parse(raw).expires > Date.now())
				throw new AgentError(409, "OAuth connection is busy; retry");
			const lease = JSON.stringify({ owner, expires: Date.now() + 30000 });
			const won = JSON.parse(
				await this.storage.lance(
					JSON.stringify({
						op: "kv.batch",
						args: {
							checks: [{ key: "auth-lease", value: raw }],
							puts: { "auth-lease": lease },
							deletes: [],
						},
					})
				)
			);
			if (!won) throw new AgentError(409, "OAuth connection is busy; retry");
			try {
				return await this.route(request);
			} finally {
				await this.storage.lance(
					JSON.stringify({
						op: "kv.batch",
						args: {
							checks: [{ key: "auth-lease", value: lease }],
							puts: {},
							deletes: ["auth-lease"],
						},
					})
				);
			}
		}
		/** Keeps credentials private while serving connection status and authenticated inference. */
		async route(request) {
			const owner = principal(this.env);
			const stored = await this.storage.get("owner");
			if (stored && stored !== owner)
				throw new AgentError(403, "OAuth connection belongs to another user");
			if (!stored) await this.storage.put("owner", owner);
			const path = new URL(request.url).pathname;
			if (path === "/auth/status" && request.method === "GET") {
				const secretNames = {
					apiKey: "USER_" + owner.slice(3, 67) + "_OPENAI_API_KEY",
					oauthToken: "USER_" + owner.slice(3, 67) + "_OPENAI_OAUTH_TOKEN",
				};
				try {
					const secret = secretCredential(this.env, owner);
					const stored = secret ?? (await this.storage.get("credentials"));
					const expired = secret && secret.expires <= Date.now();
					return Response.json({
						connected: Boolean(stored) && !expired,
						source: secret?.source ?? "device_oauth",
						provider: secret?.provider ?? "openai-codex",
						secretNames,
						...(expired
							? {
									error:
										"OAuth token expired. Replace it using Worker secrets.",
								}
							: {}),
					});
				} catch (error) {
					return Response.json({
						connected: false,
						source: "worker_secret",
						secretNames,
						error:
							error instanceof AgentError
								? error.message
								: "Provider credential is invalid",
					});
				}
			}
			if (request.method !== "POST")
				throw new AgentError(405, "Method not allowed");
			if (path === "/auth/disconnect") {
				await this.storage.delete("credentials");
				await this.storage.delete("device");
				return Response.json({ connected: false });
			}
			if (path === "/auth/start") {
				const current = await this.storage.get("device");
				if (current && current.expires > Date.now())
					return Response.json({
						userCode: current.userCode,
						verificationUri: AUTH + "/codex/device",
						expiresAt: current.expires,
						intervalSeconds: current.interval,
					});
				const value = await oauth(
					this.env,
					"/api/accounts/deviceauth/usercode",
					{ client_id: CLIENT }
				);
				const interval = Number(value.interval);
				if (
					typeof value.device_auth_id !== "string" ||
					typeof value.user_code !== "string" ||
					!Number.isFinite(interval) ||
					interval < 0 ||
					interval > 300
				)
					throw new AgentError(502, "Invalid Codex device response");
				const device = {
					id: value.device_auth_id,
					userCode: value.user_code,
					interval: Math.max(1, interval),
					expires: Date.now() + 900000,
					nextPoll: Date.now() + Math.max(1, interval) * 1000,
				};
				await this.storage.put("device", device);
				return Response.json({
					userCode: device.userCode,
					verificationUri: AUTH + "/codex/device",
					expiresAt: device.expires,
					intervalSeconds: device.interval,
				});
			}
			if (path === "/auth/poll") {
				const device = await this.storage.get("device");
				if (!device || device.expires <= Date.now())
					throw new AgentError(410, "Authorization expired; connect again");
				if (Date.now() < device.nextPoll)
					return Response.json(
						{ connected: false, nextPollAt: device.nextPoll },
						{ status: 202 }
					);
				device.nextPoll = Date.now() + device.interval * 1000;
				await this.storage.put("device", device);
				const response = await this.env.CODEX.fetch(
					AUTH + "/api/accounts/deviceauth/token",
					{
						method: "POST",
						headers: { "content-type": "application/json" },
						body: JSON.stringify({
							device_auth_id: device.id,
							user_code: device.userCode,
						}),
					}
				);
				if ([403, 404, 429].includes(response.status)) {
					await response.body?.getReader().cancel();
					if (response.status === 429) {
						device.interval += 5;
						device.nextPoll = Date.now() + device.interval * 1000;
						await this.storage.put("device", device);
					}
					return Response.json(
						{ connected: false, nextPollAt: device.nextPoll },
						{ status: 202 }
					);
				}
				if (!response.ok) {
					await response.body?.getReader().cancel();
					throw new AgentError(502, "Codex device authorization failed");
				}
				const grant = await response.json();
				if (
					typeof grant.authorization_code !== "string" ||
					typeof grant.code_verifier !== "string"
				)
					throw new AgentError(502, "Invalid Codex authorization grant");
				const value = credentials(
					await oauth(
						this.env,
						"/oauth/token",
						{
							grant_type: "authorization_code",
							client_id: CLIENT,
							code: grant.authorization_code,
							code_verifier: grant.code_verifier,
							redirect_uri: AUTH + "/deviceauth/callback",
						},
						true
					)
				);
				await this.storage.put("credentials", value);
				await this.storage.delete("device");
				return Response.json({ connected: true });
			}
			// This operation is called by the agent Worker and returns inference, never credentials.
			if (path === "/model") {
				let value =
					secretCredential(this.env, owner) ??
					(await this.storage.get("credentials"));
				if (!value)
					throw new AgentError(401, "Connect ChatGPT before starting an agent");
				if (value.source === "worker_secret" && value.expires <= Date.now())
					throw new AgentError(
						401,
						"OAuth token expired. Replace it using Worker secrets."
					);
				if (
					value.source !== "worker_secret" &&
					value.expires <= Date.now() + 60000
				) {
					value = credentials(
						await oauth(
							this.env,
							"/oauth/token",
							{
								grant_type: "refresh_token",
								client_id: CLIENT,
								refresh_token: value.refresh,
							},
							true
						)
					);
					await this.storage.put("credentials", value);
				}
				const body = await request.text();
				if (body.length > MAX_CONTEXT + 32768)
					throw new AgentError(413, "Model context is too large");
				const response = await this.env.CODEX.fetch(
					value.provider === "openai"
						? "https://api.openai.com/v1/responses"
						: "https://chatgpt.com/backend-api/codex/responses",
					{
						method: "POST",
						headers: {
							authorization: "Bearer " + value.access,
							...(value.accountId
								? {
										"chatgpt-account-id": value.accountId,
										"OpenAI-Beta": "responses=experimental",
										originator: "lakeday",
									}
								: {}),
							"content-type": "application/json",
							accept: "text/event-stream",
						},
						body,
					}
				);
				if (!response.ok) {
					await response.body?.getReader().cancel();
					throw new AgentError(
						response.status === 429 ? 429 : 502,
						`Codex inference failed (HTTP ${response.status})`
					);
				}
				return response;
			}
			throw new AgentError(404, "Not found");
		}
	}
	class AgentState {
		constructor(state, env) {
			this.storage = new AgentCheckpointStorage(state.storage);
			this.objectId = state.id.toString();
			this.env = env;
		}
		/** Reads durable run state without storing credentials or trusting caller-selected ownership. */
		async fetch(request) {
			const owner = principal(this.env);
			const stored = await this.storage.get("owner");
			if (stored && stored !== owner)
				throw new AgentError(403, "Session belongs to another user");
			if (!stored) await this.storage.put("owner", owner);
			const runs = (await this.storage.get("runs")) ?? [];
			if (request.method === "GET") {
				const runId = new URL(request.url).pathname.split("/")[4];
				if (runId) {
					const run = await this.storage.get("run:" + runId);
					if (!run) throw new AgentError(404, "Run not found");
					return Response.json({
						id: run.id,
						model: run.model ?? definition.model,
						status: run.status,
						message: run.message,
						events: run.events,
					});
				}
				return Response.json({
					runs,
					sessionId: (await this.storage.get("sessionId")) ?? null,
				});
			}
			const body = await jsonBody(request);
			const runId = request.headers.get("idempotency-key");
			if (!ID.test(runId ?? ""))
				throw new AgentError(
					400,
					"Idempotency-Key must be a portable identifier of at most 64 characters"
				);
			if (
				typeof body.message !== "string" ||
				!body.message.trim() ||
				body.message.length > 8192
			)
				throw new AgentError(400, "message must contain 1..8192 characters");
			if (
				body.model !== undefined &&
				(typeof body.model !== "string" ||
					!/^[a-zA-Z0-9_.-]{1,100}$/.test(body.model))
			)
				throw new AgentError(400, "Invalid model identifier");
			const key = "run:" + runId;
			let run = await this.storage.get(key);
			if (
				run &&
				body.model !== undefined &&
				body.model !== (run.model ?? definition.model)
			)
				throw new AgentError(409, "A resumed turn must use its original model");
			if (run && run.message !== body.message)
				throw new AgentError(
					409,
					"Idempotency key was used for a different message"
				);
			if (run?.status === "finished" || run?.status === "failed")
				return eventResponse(
					(async function* () {
						yield* run.events;
					})()
				);
			if (body.effect) {
				if (!run?.pending || run.pending.id !== body.effect.id)
					throw new AgentError(409, "No matching pending product action");
				const effectKey = "effect:" + body.effect.id;
				if (body.effect.claim === true) {
					const claimed = JSON.parse(
						await this.storage.lance(
							JSON.stringify({
								op: "kv.batch",
								args: {
									checks: [{ key: effectKey, value: null }],
									puts: { [effectKey]: JSON.stringify({ claimed: true }) },
									deletes: [],
								},
							})
						)
					);
					return Response.json({ claimed });
				}
				if (
					!Object.hasOwn(body.effect, "result") ||
					JSON.stringify(body.effect.result).length > 12000
				)
					throw new AgentError(400, "Bounded product result required");
				const receipt = await this.storage.get(effectKey);
				if (!receipt?.claimed)
					throw new AgentError(409, "Product action has not been claimed");
				// A repeated acknowledgement must agree with the first durable result.
				const resultKey = "tool:" + body.effect.id;
				const previous = await this.storage.get(resultKey);
				if (
					previous !== undefined &&
					JSON.stringify(previous) !== JSON.stringify(body.effect.result)
				)
					throw new AgentError(409, "Product receipt differs");
				await this.storage.put(resultKey, body.effect.result);
			}
			const active = await this.storage.get("active");
			if (active && active.expires > Date.now())
				throw new AgentError(409, "Session already has an active run");
			if (active && active.id !== runId) {
				const previous = await this.storage.get("run:" + active.id);
				if (!["finished", "failed"].includes(previous?.status))
					throw new AgentError(
						409,
						"Resume the interrupted run before starting another"
					);
			}
			const newRun = !run;
			if (!run) {
				if (runs.length >= 1000)
					throw new AgentError(413, "Session has reached its run limit");
				const previousMessages = (await this.storage.get("messages")) ?? [];
				const messages = conversationTail(previousMessages);
				run = {
					id: runId,
					message: body.message,
					model: body.model ?? definition.model,
					compacted: previousMessages.length - messages.length,
					status: "running",
					step: 0,
					phase: "model",
					messages: [...messages, { role: "user", content: body.message }],
					events: [],
					output: null,
					toolIndex: 0,
				};
				if (JSON.stringify(run.messages).length > MAX_CONTEXT)
					throw new AgentError(
						413,
						"Session context limit reached; start a new session"
					);
			}
			let lease = JSON.stringify({ id: runId, expires: Date.now() + 60000 });
			const old = await this.storage.lance(
				JSON.stringify({ op: "kv.get", args: { key: "lease" } })
			);
			const priorLease = JSON.parse(old);
			if (priorLease && JSON.parse(priorLease).expires > Date.now())
				throw new AgentError(409, "Session already has an active run");
			const won = JSON.parse(
				await this.storage.lance(
					JSON.stringify({
						op: "kv.batch",
						args: {
							checks: [{ key: "lease", value: JSON.parse(old) }],
							puts: { lease },
							deletes: [],
						},
					})
				)
			);
			if (!won)
				throw new AgentError(409, "Session run was claimed concurrently");
			if (newRun) {
				await this.storage.put(key, run);
				const savedRuns = (await this.storage.get("runs")) ?? [];
				savedRuns.push(runId);
				await this.storage.put("runs", savedRuns);
			}
			await this.storage.put("active", {
				id: runId,
				expires: Date.now() + 60000,
			});
			const self = this;
			const renew = async () => {
				const next = JSON.stringify({ id: runId, expires: Date.now() + 60000 });
				const won = JSON.parse(
					await self.storage.lance(
						JSON.stringify({
							op: "kv.batch",
							args: {
								checks: [{ key: "lease", value: lease }],
								puts: { lease: next },
								deletes: [],
							},
						})
					)
				);
				if (!won)
					throw new AgentError(409, "Run lease was transferred; reconnect");
				lease = next;
			};
			return eventResponse(
				(async function* () {
					let finished = false;
					try {
						const profile = await ensureProfile(
							self.env,
							owner,
							definition.name ?? "default"
						);
						let sessionId = await self.storage.get("sessionId");
						if (!sessionId) {
							// The native DO ID includes the deployed Worker namespace.
							sessionId =
								owner.slice(0, -4) + "agent:" + self.objectId.slice(-32);
							await self.checked(
								self.env.SESSION.getByName(sessionId),
								"/",
								{
									kind: "session",
									name: body.message.slice(0, 1024),
									actor_id: owner,
								},
								"agent-session"
							);
							await self.checked(
								self.env.ENTITY.getByName(profile.agentEntityId),
								"/links",
								{
									id: "chat:" + self.objectId.slice(-32),
									actor_id: owner,
									predicate: "conversation",
									about: sessionId,
									session_key: new URL(request.url).pathname.split("/")[2],
									title: body.message.slice(0, 120),
								},
								"chat:" + self.objectId.slice(-32)
							);
							await self.storage.put("sessionId", sessionId);
						}
						if (!run.memory) {
							run.memory = await readMemory(
								self.env,
								profile,
								sessionId,
								definition.learning
							);
							await self.storage.put(key, run);
						}
						const emit = async (event, type = "agent.event") => {
							await renew();
							if (run.events.length >= MAX_EVENTS)
								throw new AgentError(413, "Agent event limit reached");
							const next = {
								...event,
								threadId: sessionId,
								runId,
								id: `${runId}:${run.events.length}`,
							};
							// Journal the exact payload before the Session commits it. A lost
							// acknowledgement must never reuse this event ID for a snapshot.
							run.pendingEvent = { event: next, type };
							await self.storage.put(key, run);
							await self.checked(
								self.env.SESSION.getByName(sessionId),
								"/log",
								{
									actor_id: profile.agentEntityId,
									principal_id: owner,
									label: type,
									event: next,
								},
								next.id
							);
							delete run.pendingEvent;
							run.events.push(next);
							if (event.type === "RUN_FINISHED") {
								run.status = "finished";
								const committed = JSON.parse(
									await self.storage.lance(
										JSON.stringify({
											op: "kv.batch",
											args: {
												checks: [{ key: "lease", value: lease }],
												puts: {
													[key]: JSON.stringify(run),
													messages: JSON.stringify(run.messages),
												},
												deletes: [],
											},
										})
									)
								);
								if (!committed)
									throw new AgentError(
										409,
										"Run lease was transferred; reconnect"
									);
							} else await self.storage.put(key, run);
							await self.storage.put("active", {
								id: runId,
								expires: Date.now() + 60000,
							});
							return next;
						};
						if (run.pendingEvent) {
							await emit(run.pendingEvent.event, run.pendingEvent.type);
						} else if (!newRun) {
							// Recover pre-journal runs whose last Session write committed but
							// whose acknowledgement was lost. Only adopt this run's next ID.
							const stub = self.env.SESSION.getByName(sessionId);
							const head = await stub.fetch("https://object/");
							if (!head.ok)
								throw new AgentError(503, "Session recovery is unavailable");
							const after = Math.max(
								0,
								((await head.json()).sequence ?? 0) - 100
							);
							const response = await stub.fetch(
								"https://object/log?limit=100&after=" + after
							);
							if (!response.ok)
								throw new AgentError(503, "Session recovery is unavailable");
							for (const record of (await response.json()).events ?? []) {
								const event = record.data?.event;
								if (
									event?.runId === runId &&
									event.id === `${runId}:${run.events.length}`
								)
									run.events.push(event);
							}
							await self.storage.put(key, run);
						}
						for (const event of run.events) yield event;
						if (run.status === "finished") {
							finished = true;
							return;
						}
						if (!newRun && run.phase === "model") {
							const messages = run.messages
								.filter((m) => m.role === "user" || m.type === "message")
								.map((m, i) => ({
									id: `${runId}-committed-${i}`,
									role: m.role,
									content:
										typeof m.content === "string"
											? m.content
											: (m.content ?? [])
													.filter((c) => c.type === "output_text")
													.map((c) => c.text)
													.join(""),
								}));
							yield await emit({ type: "MESSAGES_SNAPSHOT", messages });
						}
						if (!run.events.length)
							yield await emit(
								{ type: "RUN_STARTED", input: { message: run.message } },
								"agent.run.started"
							);
						if (!run.events.some((event) => event.type === "STATE_SNAPSHOT"))
							yield await emit(
								{
									type: "STATE_SNAPSHOT",
									snapshot: { ...profile, sessionId, memory: run.memory },
								},
								"agent.memory.loaded"
							);
						if (
							run.compacted &&
							!run.events.some(
								(event) => event.name === "lakeday.context.compacted"
							)
						)
							yield await emit(
								{
									type: "CUSTOM",
									name: "lakeday.context.compacted",
									value: {
										droppedMessages: run.compacted,
										retainedMessages: run.messages.length,
										sessionId,
									},
								},
								"agent.context.compacted"
							);
						while (run.step < definition.maxSteps) {
							if (run.phase === "model") {
								const view = projectAgentComponents(
									definition.components ?? [],
									run.events
								);
								if (view.stop) throw new AgentError(422, view.stop);
								run.availableTools = definition.tools
									.filter(
										(tool) =>
											(view.tools === undefined ||
												view.tools.includes(tool.name)) &&
											(!tool.permission ||
												self.env.CODEX.permissions?.().includes(
													tool.permission
												))
									)
									.map((tool) => tool.name);
								await self.storage.put(key, run);

								if (JSON.stringify(run.messages).length > MAX_CONTEXT)
									throw new AgentError(413, "Agent context limit reached");
								await renew();
								let lastHeartbeat = Date.now();
								const response = await self.env.AGENT_AUTH.getByName(
									"auth:" + owner
								).fetch(
									new Request("https://auth/model", {
										method: "POST",
										body: JSON.stringify({
											model: run.model ?? definition.model,
											instructions:
												definition.instructions + "\n" + view.instructions,
											store: false,
											stream: true,
											input: run.messages,
											tools: definition.tools
												.filter((tool) =>
													run.availableTools.includes(tool.name)
												)
												.map((t) => ({
													type: "function",
													name: t.name,
													description: t.description,
													parameters: t.parameters,
													strict: false,
												})),
											tool_choice: "auto",
											parallel_tool_calls: false,
											include: ["reasoning.encrypted_content"],
										}),
									})
								);
								const completedItems = new Map();
								let started = false;
								const messageId = `${runId}-message-${run.step}`;
								let pendingText = "";
								let lastTextAt = 0;
								const flushText = async () => {
									const delta = pendingText;
									pendingText = "";
									const event = await emit({
										type: "TEXT_MESSAGE_CONTENT",
										messageId,
										delta,
									});
									lastTextAt = Date.now();
									return event;
								};
								for await (const event of codexEvents(response)) {
									if (
										pendingText &&
										event.type !== "response.output_text.delta"
									)
										yield await flushText();
									if (
										event.type === "lakeday.keepalive" ||
										Date.now() - lastHeartbeat >= 1000
									) {
										await renew();
										lastHeartbeat = Date.now();
										yield {
											type: "CUSTOM",
											name: "agent.heartbeat",
											value: {},
											threadId: sessionId,
											runId,
										};
									}
									if (event.type === "response.output_text.delta") {
										if (!started) {
											yield await emit({
												type: "TEXT_MESSAGE_START",
												messageId,
												role: "assistant",
											});
											started = true;
										}
										if (typeof event.delta === "string") {
											// Persist the first fragment promptly, then coalesce token-sized deltas.
											for (
												let offset = 0;
												offset < event.delta.length;
												offset += 512
											) {
												pendingText += event.delta.slice(offset, offset + 512);
												if (
													pendingText.length >= 512 ||
													Date.now() - lastTextAt >= 200
												)
													yield await flushText();
											}
										}
									}
									if (event.type === "response.output_item.done") {
										if (
											!Number.isInteger(event.output_index) ||
											event.output_index < 0 ||
											event.output_index >= 128 ||
											!event.item ||
											typeof event.item.type !== "string"
										)
											throw new AgentError(
												502,
												"Invalid completed provider output item"
											);
										completedItems.set(event.output_index, event.item);
									}
									if (event.type === "response.completed") {
										if (!Array.isArray(event.response?.output))
											throw new AgentError(
												502,
												"Codex completion has no output"
											);
										if (event.response.output.length > 128)
											throw new AgentError(
												502,
												"Too many provider output items"
											);
										// Both item completion events and the terminal response describe the same indexed output.
										event.response.output.forEach((item, index) =>
											completedItems.set(index, item)
										);
										if (!completedItems.size)
											throw new AgentError(
												502,
												"Provider completed without output items"
											);
										run.output = [...completedItems]
											.sort(([left], [right]) => left - right)
											.map(([, item]) => item);
										run.phase = "tools";
										run.toolIndex = 0;
										run.messages.push(...run.output);
										await self.storage.put(key, run);
									}
								}
								if (started)
									yield await emit({ type: "TEXT_MESSAGE_END", messageId });
							}
							const completedMessageId = `${runId}-message-${run.step}`;
							if (
								run.events.some(
									(e) =>
										e.type === "TEXT_MESSAGE_START" &&
										e.messageId === completedMessageId
								) &&
								!run.events.some(
									(e) =>
										e.type === "TEXT_MESSAGE_END" &&
										e.messageId === completedMessageId
								)
							) {
								yield await emit({
									type: "TEXT_MESSAGE_END",
									messageId: completedMessageId,
								});
							}
							const calls = run.output.filter(
								(item) => item.type === "function_call"
							);
							if (
								!calls.length &&
								definition.learning?.mode === "always" &&
								run.step + 1 < definition.maxSteps
							) {
								const verdict = learningVerdict(run.events, {
									learning: definition.learning,
									sessionId,
								});
								if (verdict.block) {
									// Send the model back once with the exact write it owes
									// before the run may finish (Agno ALWAYS; Stop-hook block).
									yield await emit(
										{
											type: "CUSTOM",
											name: "lakeday.learning.required",
											value: { reason: verdict.reason },
										},
										"agent.learning.required"
									);
									run.messages.push({ role: "user", content: verdict.reason });
									run.step++;
									run.phase = "model";
									run.output = null;
									await self.storage.put(key, run);
									continue;
								}
							}
							if (!calls.length) {
								const summary = run.output
									.filter((item) => item.type === "message")
									.flatMap((item) => item.content ?? [])
									.filter((item) => item.type === "output_text")
									.map((item) => item.text)
									.join("\n")
									.slice(0, 8192);
								const head =
									await self.env.SESSION.getByName(sessionId).fetch(
										"https://object/"
									);
								if (!head.ok)
									throw new AgentError(503, "Session context is unavailable");
								const currentContext = (await head.json()).context ?? {};
								await self.checked(
									self.env.SESSION.getByName(sessionId),
									"/context",
									{
										...currentContext,
										actor_id: profile.agentEntityId,
										principal_id: owner,
										last_run: runId,
										last_request: body.message,
										summary,
										...(definition.learning?.mode !== "off"
											? { learning: contextLedger(run.events) }
											: {}),
									},
									runId + ":context"
								);
								const completed = await emit(
									{ type: "RUN_FINISHED" },
									"agent.run.finished"
								);

								finished = true;
								yield completed;
								return;
							}
							for (; run.toolIndex < calls.length; run.toolIndex++) {
								const call = calls[run.toolIndex];
								const tool = definition.tools.find((t) => t.name === call.name);
								const operationId = `${runId}.${run.step}.${run.toolIndex}`;
								const receiptKey = "tool:" + operationId;
								let result = await self.storage.get(receiptKey);
								if (result === undefined && run.pending?.id === operationId) {
									yield await emit(
										{
											type: "CUSTOM",
											name: "lakeday.product.request",
											value: run.pending,
										},
										"agent.product.requested"
									);
									return;
								}
								if (result === undefined) {
									yield await emit(
										{
											type: "TOOL_CALL_START",
											toolCallId: call.call_id,
											toolCallName: call.name,
										},
										"agent.tool.started"
									);
									yield await emit({
										type: "TOOL_CALL_ARGS",
										toolCallId: call.call_id,
										delta: call.arguments,
									});
									yield await emit({
										type: "TOOL_CALL_END",
										toolCallId: call.call_id,
									});
									let args;
									try {
										args = JSON.parse(call.arguments);
									} catch {
										throw new AgentError(
											502,
											"Model returned invalid tool arguments"
										);
									}
									if (
										!tool ||
										(tool.permission &&
											!self.env.CODEX.permissions?.().includes(
												tool.permission
											)) ||
										(run.availableTools &&
											!run.availableTools.includes(tool.name))
									)
										result = {
											error:
												"Tool is not available in the current harness state",
										};
									else {
										validateArguments(tool.parameters, args);
										// Authors declare read-only or idempotent effects; the key survives process loss.
										await renew();
										result = await tool.execute(args, {
											env: self.env,
											actorId: profile.agentEntityId,
											userEntityId: owner,
											sessionId,
											runId,
											idempotencyKey: operationId,
										});
										if (result === undefined) result = null;
									}
									if (JSON.stringify(result).length > 16384)
										throw new AgentError(
											413,
											"Tool result exceeds 16 KiB; return a lake reference"
										);
									if (result?.kind === "lakeday.product") {
										run.pending = { ...result, id: operationId };
										await self.storage.put(key, run);
										yield await emit(
											{
												type: "CUSTOM",
												name: "lakeday.product.request",
												value: run.pending,
											},
											"agent.product.requested"
										);
										return;
									}
									await self.storage.put(receiptKey, result);
								}
								yield await emit(
									{
										type: "TOOL_CALL_RESULT",
										toolCallId: call.call_id,
										messageId: operationId,
										content: JSON.stringify(result),
										role: "tool",
									},
									"agent.tool.result"
								);
								if (result?.kind === "lakeday.ui")
									yield await emit(
										{ type: "CUSTOM", name: "lakeday.ui", value: result },
										"agent.ui.rendered"
									);
								run.messages.push({
									type: "function_call_output",
									call_id: call.call_id,
									output: JSON.stringify(result),
								});
								run.toolIndex++;
								await self.storage.put(key, run);
								run.toolIndex--;
							}
							run.step++;
							run.phase = "model";
							run.output = null;
							await self.storage.put(key, run);
						}
						throw new AgentError(422, "Agent step limit reached");
					} catch (error) {
						const event = {
							type: "RUN_ERROR",
							message:
								error instanceof AgentError
									? error.message
									: "Agent run interrupted; retry with the same idempotency key",
							code:
								error instanceof AgentError
									? String(error.status)
									: "retryable",
							runId,
						};
						if (
							error instanceof AgentError &&
							![409, 429, 502, 503].includes(error.status)
						) {
							run.events.push(event);
							run.status = "failed";
							await self.storage.put(key, run);
							finished = true;
						}
						yield event;
					} finally {
						const activeValue = JSON.stringify({ id: runId, expires: 0 });
						await self.storage.lance(
							JSON.stringify({
								op: "kv.batch",
								args: {
									checks: [{ key: "lease", value: lease }],
									puts: finished ? {} : { active: activeValue },
									deletes: finished ? ["lease", "active"] : ["lease"],
								},
							})
						);
					}
				})()
			);
		}
		/** Writes through the native object contract with a stable operation identity. */
		async checked(stub, path, body, key) {
			const response = await stub.fetch("https://object" + path, {
				method: "POST",
				headers: { "content-type": "application/json", "idempotency-key": key },
				body: JSON.stringify(body),
			});
			if (!response.ok)
				throw new AgentError(
					503,
					`Session persistence is unavailable (HTTP ${response.status})`
				);
			return response.json();
		}
	}
	const worker = {
		async fetch(request, env) {
			try {
				const owner = principal(env);
				const path = new URL(request.url).pathname;
				if (path === "/profile" && request.method === "POST")
					return Response.json(
						await ensureProfile(env, owner, definition.name ?? "default")
					);
				if (path === "/sessions" && request.method === "GET") {
					const profile = await ensureProfile(
						env,
						owner,
						definition.name ?? "default"
					);
					const after = new URL(request.url).searchParams.get("after") ?? "0";
					if (!/^\d{1,12}$/.test(after))
						throw new AgentError(400, "Invalid cursor");
					const response = await env.ENTITY.getByName(
						profile.agentEntityId
					).fetch("https://object/links?limit=100&after=" + after);
					if (!response.ok)
						throw new AgentError(503, "Conversation directory unavailable");
					const page = await response.json();
					return Response.json({
						sessions: (page.events ?? [])
							.filter((e) => e.data?.predicate === "conversation")
							.map((e) => ({
								key: e.data.session_key,
								title: e.data.title,
								sessionId: e.data.about,
							})),
						next_after: page.next_after ?? null,
					});
				}
				if (path === "/ui/evaluate" && request.method === "POST") {
					const body = await jsonBody(request);
					return await env.UI.render(
						new Request("https://view/evaluate", {
							method: "POST",
							body: JSON.stringify({ state: body.state ?? {} }),
						}),
						body.document
					);
				}

				if (/^\/auth\/(start|poll|status|disconnect)$/.test(path))
					return await env.AGENT_AUTH.getByName("auth:" + owner).fetch(request);
				const match =
					/^\/sessions\/([a-zA-Z0-9][a-zA-Z0-9_.-]{0,39})(\/runs(?:\/([a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}))?)?$/.exec(
						path
					);
				if (!match) throw new AgentError(404, "Not found");
				if (
					(match[2] && !match[3] && request.method !== "POST") ||
					((!match[2] || match[3]) && request.method !== "GET")
				)
					throw new AgentError(405, "Method not allowed");
				return await env.AGENT_STATE.getByName(
					"session:" + owner + ":" + match[1]
				).fetch(request);
			} catch (error) {
				return Response.json(
					{
						error:
							error instanceof AgentError
								? error.message
								: "Agent request failed",
					},
					{ status: error instanceof AgentError ? error.status : 500 }
				);
			}
		},
	};
	return { worker, AgentState, AgentAuth };
}

/** Describes explicit host and Worker bindings for every deployment of this agent contract. */
export function agentManifest(name, bindings = ["query", "jsx2ui"]) {
	const components = {
		query: "QUERY",
		sink: "SINK",
		jsx2ui: "JSX",
		entity: "ENTITY",
		session: "SESSION",
	};
	if (!/^[a-z][a-z0-9-]{0,62}$/.test(name))
		throw new TypeError("Invalid agent name");
	for (const binding of bindings)
		if (!Object.hasOwn(components, binding))
			throw new TypeError(`Unknown agent binding: ${binding}`);
	return {
		name,
		main: "worker.js",
		lakeday: { agent: { name, provider: "openai-codex" } },
		artifacts: { worker: {} },
		services: [
			{ binding: "CODEX", service: "codex" },
			...Array.from(new Set(["entity", "session", ...bindings])).map(
				(service) => ({ binding: components[service], service })
			),
		],
		durable_objects: {
			bindings: [
				{ name: "AGENT_STATE", class_name: "AgentState" },
				{ name: "AGENT_AUTH", class_name: "AgentAuth" },
			],
		},
	};
}
