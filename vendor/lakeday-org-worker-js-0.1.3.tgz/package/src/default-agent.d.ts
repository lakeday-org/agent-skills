import type { AgentDefinition } from "./agent.js";
/** The platform dashboard definition, deployable through the same contract as custom agents. */
declare const agent: Readonly<AgentDefinition>;
export default agent;
