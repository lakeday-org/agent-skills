/** A caller-bound control-plane client. Tokens are permission ceilings, never data grants. */
export function createAccessClient({
	origin = "https://api.lakeday.ai",
	token,
	fetch: transport = globalThis.fetch,
}) {
	const url = new URL(origin);
	if (
		url.protocol !== "https:" ||
		url.username ||
		url.password ||
		url.pathname !== "/" ||
		url.search ||
		url.hash
	)
		throw new Error("Access API requires an HTTPS origin");
	if (typeof token !== "string" || !token)
		throw new Error("An identity token is required");
	const encode = (value) => encodeURIComponent(value);
	async function request(path, method = "GET", body) {
		const response = await transport(new URL(path, url), {
			method,
			redirect: "error",
			headers: {
				authorization: `Bearer ${token}`,
				"content-type": "application/json",
				...(method === "POST"
					? { "idempotency-key": crypto.randomUUID() }
					: {}),
			},
			...(body === undefined ? {} : { body: JSON.stringify(body) }),
		});
		if (!response.ok)
			throw new Error(`Access API denied or failed: HTTP ${response.status}`);
		return response.json();
	}
	const collections = (tenant) =>
		`/v1/deployments/${encode(tenant)}/collections`;
	const collection = (tenant, id) => `${collections(tenant)}/${encode(id)}`;
	return {
		listCollections: (tenant) => request(collections(tenant)),
		createCollection: (tenant, input) =>
			request(collections(tenant), "POST", input),
		listGrants: (tenant, id) => request(`${collection(tenant, id)}/grants`),
		grant: (tenant, id, input) =>
			request(`${collection(tenant, id)}/grants`, "PUT", input),
		revoke: (tenant, id, input) =>
			request(`${collection(tenant, id)}/grants`, "DELETE", input),
		listSources: (tenant, id) => request(`${collection(tenant, id)}/sources`),
		assignSource: (tenant, id, input) =>
			request(`${collection(tenant, id)}/sources`, "POST", input),
		listTables: (tenant, id) => request(`${collection(tenant, id)}/tables`),
		setTablePolicy: (tenant, id, input) =>
			request(`${collection(tenant, id)}/tables`, "PUT", input),
		roles: (organization) =>
			request(`/v1/organizations/${encode(organization)}/roles`),
		listTokens: (organization) =>
			request(`/v1/organizations/${encode(organization)}/tokens`),
		createToken: (organization, input) =>
			request(
				`/v1/organizations/${encode(organization)}/tokens`,
				"POST",
				input
			),
		revokeToken: (organization, id) =>
			request(
				`/v1/organizations/${encode(organization)}/tokens/${encode(id)}`,
				"DELETE"
			),
	};
}
