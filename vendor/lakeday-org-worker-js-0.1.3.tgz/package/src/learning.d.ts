import type { AgentComponent, AgentTool } from "./agent";
import type { EntityEvent, Reference } from "./entity";

export type LearningMode = "always" | "agentic" | "off";
export interface LearningOptions {
	/** `always` enforces decisions at run end; `agentic` only adds tools and instructions. */
	mode?: LearningMode;
	/** Character budget of the projected context block (500..64000). */
	budget?: number;
	/** How many times one run may be sent back to record knowledge (0..3). */
	maxNudges?: number;
}
export interface NormalizedLearning {
	mode: LearningMode;
	budget: number;
	maxNudges: number;
}
export const LEARNING_MODES: readonly LearningMode[];
export function normalizeLearning(
	value: LearningMode | LearningOptions | boolean | null | undefined
): NormalizedLearning;

export type ToolKind =
	| "consequential"
	| "measurement"
	| "recording"
	| "read"
	| "code"
	| "other";
export interface NormalizedTool {
	name: string;
	lakedayTool: string | null;
	input: Record<string, unknown>;
	output: unknown;
	error: string | null;
}
export const CONSEQUENTIAL_TOOLS: Set<string>;
export const MEASUREMENT_TOOLS: Set<string>;
export const RECORDING_TOOLS: Set<string>;
export const RECORDING_OPERATIONS: Set<string>;
export function knowledgeOperation(lakedayTool: string | null | undefined): string | null;
export function clip(text: unknown, max?: number): string;
export function sanitizeId(value: unknown, max?: number): string;
export function normalizeToolCall(call: {
	name?: string;
	input?: unknown;
	output?: unknown;
	error?: string | null;
	serverName?: string;
}): NormalizedTool;
export function lakedayToolName(
	name: string,
	serverName?: string
): string | null;
export function toolError(output: unknown): string | null;
export function classifyTool(
	tool: Partial<NormalizedTool> | null | undefined
): ToolKind;
export function tablesInSql(sql: unknown): string[];
export function evidenceFor(tool: NormalizedTool): Reference[];
export function aboutFor(tool: NormalizedTool): string | null;
export function toolEventData(
	tool: NormalizedTool,
	harness?: string
): Record<string, unknown>;
export function externalDatasetId(source: unknown): string;

export type ProvenanceStep =
	| { op: "ensure-entity"; id: string; data: Record<string, unknown> }
	| { op: "link"; entity: string; data: Record<string, unknown> };
export function provenancePlan(
	tool: NormalizedTool,
	options?: { sessionId?: string; projectEntity?: string }
): ProvenanceStep[];

export interface ProjectionComponent<S = unknown> {
	name: string;
	initial(): S;
	reduce(state: S, event: Record<string, unknown>): S;
	view(state: S, context?: { projectEntity?: string }): string[];
}
export const goalComponent: ProjectionComponent;
export const contextComponent: ProjectionComponent;
export const decisionsComponent: ProjectionComponent;
export const referencesComponent: ProjectionComponent;
export const recentComponent: ProjectionComponent;
export const uncertainComponent: ProjectionComponent;
export const factsComponent: ProjectionComponent;
export const SESSION_COMPONENTS: ProjectionComponent[];
export function fold(
	components: ProjectionComponent[],
	events: Record<string, unknown>[] | null | undefined
): Map<string, unknown>;
export function priorDecisionsView(
	events: EntityEvent[] | null | undefined,
	projectEntity?: string
): string[];
export function renderContext(input: {
	sessionId: string;
	projectEntity?: string;
	tenant?: string;
	parts: string[][];
	budget?: number;
}): string;
export function projectSession(input: {
	sessionEvents: Record<string, unknown>[];
	factEvents?: Record<string, unknown>[];
	priorDecisions?: EntityEvent[];
	sessionId: string;
	projectEntity?: string;
	tenant?: string;
	budget?: number;
}): { states: Map<string, unknown>; text: string };
export function summarizeForContext(
	states: Map<string, unknown>,
	options?: { reason?: string; turnSummary?: string }
): Record<string, unknown>;

export interface TurnLedgerTool {
	name: string;
	lakedayTool: string | null;
	kind: ToolKind;
	ok: boolean;
	label: string;
}
export interface TurnLedger {
	tools: TurnLedgerTool[];
	decisions: number;
	outcomes: number;
	nudges?: number;
	stopBlocks?: number;
	measuredAfterDecision?: boolean;
}
export interface Verdict {
	block: boolean;
	reason?: string;
}
export function stopVerdict(
	turn: TurnLedger,
	options?: {
		enforce?: boolean;
		maxNudges?: number;
		stopActive?: boolean;
		sessionId?: string;
		projectEntity?: string;
		surface?: "mcp" | "agent";
		openDecisions?: number;
		measuredAfterDecision?: boolean;
	}
): Verdict;
export function runLedger(events: Record<string, unknown>[]): TurnLedger;
export function learningVerdict(
	events: Record<string, unknown>[],
	options: {
		learning: NormalizedLearning;
		sessionId?: string;
		openDecisions?: number;
	}
): Verdict;
export function learningComponents(
	learning: NormalizedLearning
): AgentComponent[];
export function learningTools(
	call: (
		binding: { fetch(input: string, init?: RequestInit): Promise<Response> },
		path: string,
		body?: unknown,
		key?: string
	) => Promise<unknown>,
	options?: { existing?: string[] }
): AgentTool[];
