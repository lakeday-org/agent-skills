# @lakeday-org/worker-js

Bundles a Cloudflare-shaped JavaScript Worker. Writes a digest and a
Wrangler-shaped manifest. The hosted runtime loads the JS module in V8.

```jsonc
{
  "name": "counter",
  "main": "worker.js",
  "compatibility_date": "2026-08-27",
  "durable_objects": {
    "bindings": [{ "name": "COUNTER", "class_name": "Counter" }]
  },
  "migrations": [{ "tag": "v1", "new_sqlite_classes": ["Counter"] }]
}
```

```js
import { DurableObject } from "cloudflare:workers";

export class Counter extends DurableObject {
  async fetch() {
    const row = this.ctx.storage.sql.exec("SELECT 1 AS n").one();
    return Response.json(row);
  }
}

export default {
  async fetch(request, env) {
    return env.COUNTER.get(env.COUNTER.idFromName("global")).fetch(request);
  },
};
```

```sh
npm install --save-dev @lakeday-org/worker-js
npx lakeday-worker-build ./my-worker --out ./build
```

Unknown manifest keys are errors. Supported extras:

```jsonc
"triggers": {
  "crons": [{ "cron": "0 0 * * *", "start_date": "2024-01-01T00:00:00Z", "max_concurrent": 4 }]
},
"pipelines": [{ "binding": "STREAM", "stream": "stream-id" }]
```

`env.STREAM.send(records, { eventIds })` appends JSON (max 5 MiB).
`ctx.storage` is KV + SQL + alarms. `ctx.waitUntil` is awaited before the
event ends (known Cloudflare divergence).

```sh
pnpm --dir packages/worker-js test
```

## Native V8 agents

Import `defineAgent`, `createAgentRuntime`, or `agentManifest` from
`@lakeday-org/worker-js/agent`. The built-in dashboard agent and custom agents
use this same harness. `lk agent create analyst --file ./agent.ts --binding query`
bundles a definition and submits an ordinary Worker with explicit grants.
See [V8 agents](https://lakeday.ai/docs/built-ins/agents) for OAuth, AG-UI events,
recovery, limits, and authoring contracts. The native Codex and Lance bindings
are supplied by Lakeday V8, not by Miniflare or workerd.

The pure learning helpers used by the V8 harness, MCP server, and coding-agent
hooks are published at `@lakeday-org/worker-js/learning`:

```js
import { projectSession, stopVerdict } from "@lakeday-org/worker-js/learning";
```

After changing agent sources, run `pnpm run sync:agent` here and
`node lakeday/system/agent/build.mjs` from the repository root to regenerate
CLI templates and the default runtime bundle.

## Collection access

Workspace roles control administration and Worker entrypoints. Source collections
control which managed data the authenticated caller can read, write, or share.
Tokens use explicit permission limits and inherit their owner's live grants.
The Query built-in is shared; each request gets only its caller's authorized tables.

```js
import { createAccessClient } from "@lakeday-org/worker-js";
const access = createAccessClient({ token: process.env.LAKEDAY_API_TOKEN });
await access.assignSource("TENANT", "sales", {
  lake_namespace: "default", worker: "system", binding: "STREAM", source_name: "sales-events",
});
await access.grant("TENANT", "sales", { email: "alice@example.com", role: "collection-reader" });
```

Assign sources before their first storage access. Source collection ownership is
immutable. Scheduled Workers and alarms require an explicitly configured,
host-only `SERVICE_IDENTITY_TOKEN`; platform invocations have no implicit data
access. Owner-column row policies are applied by Query and deny raw storage
operations in the restricted collection. See [Authorization](https://lakeday.ai/docs/concepts/authorization).
